import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

// --- Types ---

export type Plan = 'free' | 'silver' | 'gold';

export type User = {
  id: string;
  email: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'non-binary' | 'other';
  location: string;
  bio: string;
  interests: string[];
  photos: string[];
  coins: number;
  isVerified: boolean;
  isOnline: boolean;
  lastActive: string; // ISO date
  plan: Plan;
  friends: string[]; // User IDs
  blocked: string[]; // User IDs
  role: 'user' | 'admin';
};

export type Message = {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
  type?: 'text' | 'gift';
  giftId?: string;
};

export type Match = {
  id: string;
  users: [string, string];
  timestamp: string;
};

export type Notification = {
  id: string;
  userId: string;
  type: 'match' | 'message' | 'gift' | 'friend_request' | 'system';
  content: string;
  read: boolean;
  timestamp: string;
  data?: any; // Extra data like senderId
};

export type Transaction = {
  id: string;
  userId: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  timestamp: string;
};

export type Story = {
  id: string;
  userId: string;
  imageUrl: string;
  caption?: string;
  timestamp: string;
  expiresAt: string;
};

export type Gift = {
  id: string;
  name: string;
  icon: string;
  cost: number;
  value: number; // Value receiver gets
};

export type Room = {
  id: string;
  name: string;
  hostId: string;
  participants: string[]; // User IDs
  category: 'chat' | 'dating' | 'music' | 'gaming';
  isActive: boolean;
};

export type Game = {
  id: string;
  name: string;
  cost: number;
  prize: number; // Max prize
  type: 'wheel' | 'slots' | 'card';
};

// --- Mock Data ---

import stock1 from '@assets/stock_images/portrait_of_attracti_888140c6.jpg';
import stock2 from '@assets/stock_images/portrait_of_handsome_85560e2e.jpg';
import stock3 from '@assets/stock_images/portrait_of_creative_0ba2bb05.jpg';
import stock4 from '@assets/stock_images/portrait_of_athletic_1a4f067a.jpg';

const MOCK_USERS: User[] = [
  {
    id: 'user-1',
    email: 'sarah@example.com',
    name: 'Sarah',
    age: 24,
    gender: 'female',
    location: 'New York, NY',
    bio: 'Artist and coffee lover. Looking for someone to explore galleries with.',
    interests: ['Art', 'Coffee', 'Travel', 'Music'],
    photos: [stock1],
    coins: 100,
    isVerified: true,
    isOnline: true,
    lastActive: new Date().toISOString(),
    plan: 'gold',
    friends: [],
    blocked: [],
    role: 'user'
  },
  {
    id: 'user-2',
    email: 'mike@example.com',
    name: 'Mike',
    age: 27,
    gender: 'male',
    location: 'Brooklyn, NY',
    bio: 'Software engineer by day, musician by night.',
    interests: ['Tech', 'Guitar', 'Hiking', 'Beer'],
    photos: [stock2],
    coins: 50,
    isVerified: true,
    isOnline: false,
    lastActive: new Date(Date.now() - 3600000).toISOString(),
    plan: 'free',
    friends: [],
    blocked: [],
    role: 'user'
  },
  {
    id: 'user-3',
    email: 'elena@example.com',
    name: 'Elena',
    age: 22,
    gender: 'female',
    location: 'Queens, NY',
    bio: 'Graphic designer. I love color and chaos.',
    interests: ['Design', 'Fashion', 'Photography'],
    photos: [stock3],
    coins: 200,
    isVerified: false,
    isOnline: true,
    lastActive: new Date().toISOString(),
    plan: 'silver',
    friends: [],
    blocked: [],
    role: 'user'
  },
  {
    id: 'user-4',
    email: 'david@example.com',
    name: 'David',
    age: 29,
    gender: 'male',
    location: 'Manhattan, NY',
    bio: 'Always active. Gym, hiking, running. Join me?',
    interests: ['Fitness', 'Hiking', 'Running', 'Health'],
    photos: [stock4],
    coins: 0,
    isVerified: true,
    isOnline: true,
    lastActive: new Date().toISOString(),
    plan: 'free',
    friends: [],
    blocked: [],
    role: 'user'
  },
  {
    id: 'admin-main',
    email: 'sundayukeme457@gmail.com',
    name: 'Super Admin',
    age: 99,
    gender: 'other',
    location: 'HQ',
    bio: 'System Administrator',
    interests: ['Control', 'Management'],
    photos: [],
    coins: 9999999,
    isVerified: true,
    isOnline: true,
    lastActive: new Date().toISOString(),
    plan: 'gold',
    friends: [],
    blocked: [],
    role: 'admin'
  }
];

const GIFTS: Gift[] = [
  { id: 'gift-rose', name: 'Rose', icon: '🌹', cost: 10, value: 5 },
  { id: 'gift-coffee', name: 'Coffee', icon: '☕', cost: 25, value: 10 },
  { id: 'gift-chocolate', name: 'Chocolate', icon: '🍫', cost: 50, value: 20 },
  { id: 'gift-diamond', name: 'Diamond', icon: '💎', cost: 500, value: 250 },
  { id: 'gift-car', name: 'Sports Car', icon: '🏎️', cost: 5000, value: 2500 },
  { id: 'gift-yacht', name: 'Yacht', icon: '🛥️', cost: 10000, value: 5000 },
];

const GAMES: Game[] = [
  { id: 'game-wheel', name: 'Fortune Wheel', cost: 20, prize: 500, type: 'wheel' },
  { id: 'game-slots', name: 'Love Slots', cost: 50, prize: 2000, type: 'slots' },
];

// --- Store ---

interface AppState {
  currentUser: User | null;
  users: User[];
  messages: Message[];
  matches: Match[];
  notifications: Notification[];
  likes: Record<string, string[]>;
  dislikes: Record<string, string[]>;
  transactions: Transaction[];
  stories: Story[];
  gifts: Gift[];
  rooms: Room[];
  games: Game[];
  
  // Actions
  login: (email: string, password: string) => boolean;
  signup: (userData: Partial<User>) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  likeUser: (targetId: string) => void;
  dislikeUser: (targetId: string) => void;
  sendMessage: (receiverId: string, content: string, type?: 'text' | 'gift', giftId?: string) => void;
  markNotificationsRead: () => void;
  
  // Economy
  addCoins: (amount: number, description: string) => void;
  spendCoins: (amount: number, description: string) => boolean;
  upgradePlan: (plan: Plan) => void;
  sendGift: (receiverId: string, giftId: string) => boolean;
  
  // Content
  postStory: (imageUrl: string, caption?: string) => void;
  
  // Live & Games
  createRoom: (name: string, category: Room['category']) => void;
  joinRoom: (roomId: string) => void;
  leaveRoom: (roomId: string) => void;
  playGame: (gameId: string) => { won: boolean, prize: number };

  // Admin Actions
  banUser: (userId: string) => void;
  verifyUser: (userId: string) => void;
  runAdminCommand: (command: string) => string;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: MOCK_USERS,
      messages: [],
      matches: [],
      notifications: [],
      likes: {},
      dislikes: {},
      transactions: [],
      stories: [],
      gifts: GIFTS,
      rooms: [
        { id: 'room-1', name: "Chill Vibes 🎵", hostId: 'user-1', participants: ['user-1', 'user-2'], category: 'music', isActive: true },
        { id: 'room-2', name: "Singles Chat ❤️", hostId: 'user-3', participants: ['user-3', 'user-4'], category: 'dating', isActive: true },
      ],
      games: GAMES,

      login: (email, password) => {
        if (email === 'sundayukeme457@gmail.com' && password === '08164590231') {
           const admin = get().users.find(u => u.email === email);
           if (admin) {
             set({ currentUser: admin });
             return true;
           }
        }

        const user = get().users.find(u => u.email === email);
        if (user) {
          if (user.role === 'admin' && email !== 'sundayukeme457@gmail.com') return false; 
          set({ currentUser: user });
          return true;
        }
        return false;
      },

      signup: (userData) => {
        const newUser: User = {
          id: `user-${Date.now()}`,
          email: userData.email!,
          name: userData.name || 'New User',
          age: userData.age || 18,
          gender: userData.gender || 'other',
          location: userData.location || 'Unknown',
          bio: userData.bio || '',
          interests: userData.interests || [],
          photos: userData.photos || [],
          coins: 100,
          isVerified: false,
          isOnline: true,
          lastActive: new Date().toISOString(),
          plan: 'free',
          friends: [],
          blocked: [],
          role: 'user',
          ...userData
        } as User;
        
        set(state => ({ 
          users: [...state.users, newUser],
          currentUser: newUser,
          transactions: [...state.transactions, {
            id: `tx-${Date.now()}`,
            userId: newUser.id,
            type: 'credit',
            amount: 100,
            description: 'Welcome Bonus',
            timestamp: new Date().toISOString()
          }]
        }));
      },

      logout: () => set({ currentUser: null }),

      updateUser: (updates) => {
        set(state => {
          if (!state.currentUser) return state;
          const updatedUser = { ...state.currentUser, ...updates };
          return {
            currentUser: updatedUser,
            users: state.users.map(u => u.id === state.currentUser!.id ? updatedUser : u)
          };
        });
      },

      likeUser: (targetId) => {
        const { currentUser, likes, users } = get();
        if (!currentUser) return;

        const currentLikes = likes[currentUser.id] || [];
        if (currentLikes.includes(targetId)) return;

        const newLikes = { ...likes, [currentUser.id]: [...currentLikes, targetId] };

        // Check for match
        const targetLikes = likes[targetId] || [];
        const isMatch = targetLikes.includes(currentUser.id);

        let newMatches = get().matches;
        let newNotifications = get().notifications;

        if (isMatch) {
          const matchId = `match-${Date.now()}`;
          newMatches = [...newMatches, {
            id: matchId,
            users: [currentUser.id, targetId],
            timestamp: new Date().toISOString()
          }];
          
          newNotifications = [
            ...newNotifications,
            {
              id: `notif-${Date.now()}-1`,
              userId: currentUser.id,
              type: 'match',
              content: `You matched with ${users.find(u => u.id === targetId)?.name}!`,
              read: false,
              timestamp: new Date().toISOString(),
              data: { matchId, partnerId: targetId }
            },
            {
              id: `notif-${Date.now()}-2`,
              userId: targetId,
              type: 'match',
              content: `You matched with ${currentUser.name}!`,
              read: false,
              timestamp: new Date().toISOString(),
              data: { matchId, partnerId: currentUser.id }
            }
          ];
        }

        set({ likes: newLikes, matches: newMatches, notifications: newNotifications });
      },

      dislikeUser: (targetId) => {
        const { currentUser, dislikes } = get();
        if (!currentUser) return;
        
        const currentDislikes = dislikes[currentUser.id] || [];
        if (currentDislikes.includes(targetId)) return;

        set({ dislikes: { ...dislikes, [currentUser.id]: [...currentDislikes, targetId] } });
      },

      sendMessage: (receiverId, content, type = 'text', giftId) => {
        const { currentUser } = get();
        if (!currentUser) return;

        const newMessage: Message = {
          id: `msg-${Date.now()}`,
          senderId: currentUser.id,
          receiverId,
          content,
          timestamp: new Date().toISOString(),
          read: false,
          type,
          giftId
        };

        set(state => ({ messages: [...state.messages, newMessage] }));
      },

      markNotificationsRead: () => {
        const { currentUser } = get();
        if (!currentUser) return;
        
        set(state => ({
          notifications: state.notifications.map(n => 
            n.userId === currentUser.id ? { ...n, read: true } : n
          )
        }));
      },

      addCoins: (amount, description) => {
        const { currentUser } = get();
        if (!currentUser) return;
        
        get().updateUser({ coins: currentUser.coins + amount });
        
        set(state => ({
          transactions: [...state.transactions, {
            id: `tx-${Date.now()}`,
            userId: currentUser.id,
            type: 'credit',
            amount,
            description,
            timestamp: new Date().toISOString()
          }]
        }));
      },

      spendCoins: (amount, description) => {
        const { currentUser } = get();
        if (!currentUser || currentUser.coins < amount) return false;
        
        get().updateUser({ coins: currentUser.coins - amount });
        
        set(state => ({
          transactions: [...state.transactions, {
            id: `tx-${Date.now()}`,
            userId: currentUser.id,
            type: 'debit',
            amount,
            description,
            timestamp: new Date().toISOString()
          }]
        }));
        return true;
      },

      upgradePlan: (plan) => {
        const { currentUser, spendCoins, updateUser } = get();
        if (!currentUser) return;
        
        let cost = 0;
        if (plan === 'silver') cost = 500;
        if (plan === 'gold') cost = 1000;

        if (currentUser.plan === 'gold' && plan === 'silver') {
           updateUser({ plan });
           return;
        }

        if (spendCoins(cost, `Upgraded to ${plan} plan`)) {
          updateUser({ plan });
        }
      },

      sendGift: (receiverId, giftId) => {
        const { currentUser, gifts, spendCoins, users, sendMessage } = get();
        if (!currentUser) return false;
        
        const gift = gifts.find(g => g.id === giftId);
        if (!gift) return false;

        // Deduct from sender
        if (spendCoins(gift.cost, `Sent gift ${gift.name}`)) {
          // Add to receiver (value transfer)
          const receiver = users.find(u => u.id === receiverId);
          if (receiver) {
             const updatedReceiver = { ...receiver, coins: receiver.coins + gift.value };
             set(state => ({
               users: state.users.map(u => u.id === receiver.id ? updatedReceiver : u),
               // Log transaction for receiver
               transactions: [...state.transactions, {
                  id: `tx-${Date.now()}-recv`,
                  userId: receiver.id,
                  type: 'credit',
                  amount: gift.value,
                  description: `Received gift ${gift.name} from ${currentUser.name}`,
                  timestamp: new Date().toISOString()
               }]
             }));
          }

          // Send message
          sendMessage(receiverId, `Sent a gift: ${gift.name}`, 'gift', giftId);

          // Notify Receiver
          set(state => ({
             notifications: [...state.notifications, {
               id: `notif-${Date.now()}`,
               userId: receiverId,
               type: 'gift',
               content: `${currentUser.name} sent you a ${gift.name} ${gift.icon}!`,
               read: false,
               timestamp: new Date().toISOString(),
               data: { senderId: currentUser.id, giftId }
             }]
          }));
          return true;
        }
        return false;
      },

      postStory: (imageUrl, caption) => {
        const { currentUser } = get();
        if (!currentUser) return;

        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24);

        set(state => ({
          stories: [...state.stories, {
            id: `story-${Date.now()}`,
            userId: currentUser.id,
            imageUrl,
            caption,
            timestamp: new Date().toISOString(),
            expiresAt: expiresAt.toISOString()
          }]
        }));
      },

      createRoom: (name, category) => {
        const { currentUser } = get();
        if (!currentUser) return;

        const newRoom: Room = {
          id: `room-${Date.now()}`,
          name,
          hostId: currentUser.id,
          participants: [currentUser.id],
          category,
          isActive: true
        };

        set(state => ({ rooms: [newRoom, ...state.rooms] }));
      },

      joinRoom: (roomId) => {
        const { currentUser } = get();
        if (!currentUser) return;

        set(state => ({
          rooms: state.rooms.map(r => 
            r.id === roomId && !r.participants.includes(currentUser.id)
              ? { ...r, participants: [...r.participants, currentUser.id] }
              : r
          )
        }));
      },

      leaveRoom: (roomId) => {
        const { currentUser } = get();
        if (!currentUser) return;
        
        set(state => ({
           rooms: state.rooms.map(r => 
             r.id === roomId
               ? { ...r, participants: r.participants.filter(id => id !== currentUser.id) }
               : r
           )
        }));
      },

      playGame: (gameId) => {
         const { currentUser, games, spendCoins, addCoins } = get();
         if (!currentUser) return { won: false, prize: 0 };
         
         const game = games.find(g => g.id === gameId);
         if (!game) return { won: false, prize: 0 };

         if (!spendCoins(game.cost, `Played ${game.name}`)) return { won: false, prize: 0 };

         // Simple logic: 30% chance to win
         const won = Math.random() < 0.3;
         const prize = won ? Math.floor(Math.random() * game.prize) + game.cost : 0; // Win cost back + random amount

         if (won) {
            addCoins(prize, `Won on ${game.name}`);
         }

         return { won, prize };
      },

      banUser: (userId) => {
        set(state => ({
          users: state.users.filter(u => u.id !== userId)
        }));
      },

      verifyUser: (userId) => {
         set(state => ({
          users: state.users.map(u => u.id === userId ? { ...u, isVerified: true } : u)
        }));
      },

      runAdminCommand: (command) => {
        const state = get();
        const cmd = command.toLowerCase().trim();

        if (cmd.startsWith("ban user")) {
           const nameOrId = cmd.replace("ban user", "").trim();
           const user = state.users.find(u => u.name.toLowerCase().includes(nameOrId.toLowerCase()) || u.id === nameOrId);
           if (user) {
             state.banUser(user.id);
             return `User ${user.name} has been banned.`;
           }
           return `User ${nameOrId} not found.`;
        }

        if (cmd.startsWith("verify user")) {
           const nameOrId = cmd.replace("verify user", "").trim();
           const user = state.users.find(u => u.name.toLowerCase().includes(nameOrId.toLowerCase()) || u.id === nameOrId);
           if (user) {
             state.verifyUser(user.id);
             return `User ${user.name} has been verified.`;
           }
           return `User ${nameOrId} not found.`;
        }

        if (cmd.startsWith("give coins")) {
           const parts = cmd.split(" ");
           const amount = parseInt(parts[2]);
           const nameOrId = parts.slice(4).join(" ");
           
           if (!amount || !nameOrId) return "Invalid format. Use: give coins [amount] to [name]";

           if (nameOrId === "everyone") {
             set(s => ({
               users: s.users.map(u => ({ ...u, coins: u.coins + amount }))
             }));
             return `Gave ${amount} coins to everyone.`;
           }

           const user = state.users.find(u => u.name.toLowerCase().includes(nameOrId.toLowerCase()) || u.id === nameOrId);
           if (user) {
             set(s => ({
               users: s.users.map(u => u.id === user.id ? { ...u, coins: u.coins + amount } : u)
             }));
             return `Gave ${amount} coins to ${user.name}.`;
           }
           return `User ${nameOrId} not found.`;
        }
        
        if (cmd === "list users") {
          return `Users: ${state.users.map(u => u.name).join(", ")}`;
        }

        if (cmd === "count matches") {
          return `Total matches: ${state.matches.length}`;
        }

        return "Command not recognized. Try 'ban user [name]', 'verify user [name]', 'give coins [amount] to [name]', or 'list users'.";
      }
    }),
    {
      name: 'spark-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
