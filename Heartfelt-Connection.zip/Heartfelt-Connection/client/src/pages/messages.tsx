import { useState } from "react";
import { useStore, User, Message } from "@/lib/store";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, MoreVertical, Phone, Video } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { GiftModal } from "@/components/gifts/gift-modal";

export default function MessagesPage() {
  const { currentUser, matches, users, messages, sendMessage, gifts } = useStore();
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");

  if (!currentUser) return null;

  // Enriched Matches (with user data)
  const myMatches = matches
    .filter(m => m.users.includes(currentUser.id))
    .map(m => {
      const partnerId = m.users.find(id => id !== currentUser.id)!;
      return {
        ...m,
        partner: users.find(u => u.id === partnerId)!
      };
    });

  // Selected Chat Data
  const selectedMatch = myMatches.find(m => m.id === selectedMatchId);
  const currentChatMessages = selectedMatch 
    ? messages.filter(msg => 
        (msg.senderId === currentUser.id && msg.receiverId === selectedMatch.partner.id) ||
        (msg.senderId === selectedMatch.partner.id && msg.receiverId === currentUser.id)
      ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    : [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatch || !messageText.trim()) return;
    sendMessage(selectedMatch.partner.id, messageText);
    setMessageText("");
  };

  const getGiftDetails = (giftId?: string) => {
    return gifts.find(g => g.id === giftId);
  };

  // Chat View
  if (selectedMatch) {
    return (
      <div className="flex flex-col h-[calc(100vh-64px)] bg-background">
        {/* Chat Header */}
        <header className="p-4 border-b flex items-center justify-between bg-white/80 dark:bg-black/80 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => setSelectedMatchId(null)} className="-ml-2">
              ←
            </Button>
            <Avatar>
              <AvatarImage src={selectedMatch.partner.photos[0]} />
              <AvatarFallback>{selectedMatch.partner.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-bold text-sm">{selectedMatch.partner.name}</h3>
              <span className="text-xs text-green-500 flex items-center gap-1">
                ● Online
              </span>
            </div>
          </div>
          <div className="flex gap-1">
            <GiftModal receiverId={selectedMatch.partner.id} />
            <Button variant="ghost" size="icon"><Phone size={20} /></Button>
            <Button variant="ghost" size="icon"><Video size={20} /></Button>
          </div>
        </header>

        {/* Messages Area */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4 pb-4">
            {currentChatMessages.length === 0 && (
              <div className="text-center text-muted-foreground text-sm py-10">
                You matched with {selectedMatch.partner.name}!<br/>
                Say hello 👋
              </div>
            )}
            {currentChatMessages.map(msg => (
              <div 
                key={msg.id} 
                className={`flex ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                    msg.type === 'gift' 
                      ? 'bg-yellow-100 text-yellow-900 border border-yellow-300' 
                      : msg.senderId === currentUser.id 
                        ? 'bg-primary text-primary-foreground rounded-tr-none' 
                        : 'bg-muted rounded-tl-none'
                  }`}
                >
                  {msg.type === 'gift' && msg.giftId ? (
                     <div className="flex flex-col items-center gap-1 py-1">
                       <span className="text-3xl">{getGiftDetails(msg.giftId)?.icon}</span>
                       <span className="font-bold">{getGiftDetails(msg.giftId)?.name}</span>
                       <span className="opacity-75 text-xs italic">Gift Sent</span>
                     </div>
                  ) : msg.content}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="p-4 bg-background border-t">
          <form onSubmit={handleSend} className="flex gap-2">
            <Input 
              value={messageText}
              onChange={e => setMessageText(e.target.value)}
              placeholder="Type a message..."
              className="rounded-full"
            />
            <Button type="submit" size="icon" className="rounded-full shrink-0">
              <Send size={18} />
            </Button>
          </form>
        </div>
      </div>
    );
  }

  // Matches List View
  return (
    <div className="h-[calc(100vh-64px)] flex flex-col bg-background">
      <header className="p-4 border-b">
        <h1 className="text-2xl font-heading font-bold text-primary">Messages</h1>
      </header>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* New Matches Row */}
          <div>
            <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3">New Matches</h2>
            <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
              {myMatches.length === 0 && <p className="text-sm text-muted-foreground">No matches yet. Keep swiping!</p>}
              {myMatches.map(match => (
                <div 
                  key={match.id} 
                  className="flex flex-col items-center gap-2 cursor-pointer min-w-[70px]"
                  onClick={() => setSelectedMatchId(match.id)}
                >
                  <Avatar className="w-16 h-16 border-2 border-primary p-0.5">
                    <AvatarImage src={match.partner.photos[0]} className="rounded-full object-cover" />
                    <AvatarFallback>{match.partner.name[0]}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs font-medium truncate w-full text-center">{match.partner.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Conversations List */}
          <div>
            <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3">Conversations</h2>
            <div className="space-y-1">
              {myMatches.map(match => {
                 const lastMsg = messages
                   .filter(m => (m.senderId === match.users[0] && m.receiverId === match.users[1]) || (m.senderId === match.users[1] && m.receiverId === match.users[0]))
                   .sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];

                 return (
                  <div 
                    key={match.id}
                    className="flex items-center gap-4 p-3 hover:bg-muted/50 rounded-xl cursor-pointer transition-colors"
                    onClick={() => setSelectedMatchId(match.id)}
                  >
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={match.partner.photos[0]} />
                      <AvatarFallback>{match.partner.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 overflow-hidden">
                      <div className="flex justify-between items-baseline">
                        <h4 className="font-bold">{match.partner.name}</h4>
                        {lastMsg && (
                          <span className="text-[10px] text-muted-foreground">
                            {formatDistanceToNow(new Date(lastMsg.timestamp), { addSuffix: true })}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {lastMsg ? (lastMsg.type === 'gift' ? '🎁 Sent a gift' : lastMsg.content) : "Start the conversation!"}
                      </p>
                    </div>
                  </div>
                 );
              })}
              {myMatches.length === 0 && (
                 <div className="text-center py-8 text-muted-foreground">
                   No conversations yet.
                 </div>
              )}
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
