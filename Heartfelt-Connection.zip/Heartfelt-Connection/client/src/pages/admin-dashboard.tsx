import { useStore } from "@/lib/store";
import { useLocation } from "wouter";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { AIConsole } from "@/components/admin/ai-console";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ShieldCheck, Ban, Trash2, Coins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// This will act as the layout and the main dashboard view
export default function AdminDashboard() {
  const { currentUser, users, banUser, verifyUser, matches, messages, transactions } = useStore();
  const [location] = useLocation();
  const { toast } = useToast();

  if (!currentUser || currentUser.role !== 'admin') return null;

  const renderContent = () => {
    // Route matching (simple manual check since we are inside a parent route)
    if (location === '/admin/ai') {
      return (
        <div className="space-y-6">
          <h2 className="text-3xl font-bold font-heading">AI Command Console</h2>
          <p className="text-muted-foreground">
            Execute natural language commands to control the platform. 
            Try: <span className="font-mono bg-muted px-1 rounded">ban user Sarah</span> or <span className="font-mono bg-muted px-1 rounded">give coins 500 to everyone</span>
          </p>
          <AIConsole />
        </div>
      );
    }

    if (location === '/admin/users') {
       return (
         <div className="space-y-6">
           <h2 className="text-3xl font-bold font-heading">User Management</h2>
           <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Coins</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map(user => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <Avatar className="w-8 h-8">
                             <img src={user.photos[0]} className="w-full h-full object-cover" />
                          </Avatar>
                          <div>
                            <div>{user.name}</div>
                            <div className="text-xs text-muted-foreground">{user.email}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.role === 'admin' ? 'destructive' : 'secondary'}>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>{user.coins}</TableCell>
                      <TableCell>
                        {user.isVerified ? (
                          <Badge variant="outline" className="border-green-500 text-green-500">Verified</Badge>
                        ) : (
                          <Badge variant="outline">Unverified</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right space-x-2">
                        {user.role !== 'admin' && (
                          <>
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => {
                                verifyUser(user.id);
                                toast({ title: "Verified" });
                              }}
                            >
                              <ShieldCheck size={16} className="text-green-500" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => {
                                banUser(user.id);
                                toast({ title: "Banned" });
                              }}
                            >
                              <Ban size={16} className="text-destructive" />
                            </Button>
                          </>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
           </Card>
         </div>
       );
    }

    // Default: Dashboard Overview
    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold font-heading">Overview</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <Coins className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$45,231.89</div>
              <p className="text-xs text-muted-foreground">+20.1% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{users.length}</div>
              <p className="text-xs text-muted-foreground">+180 since last hour</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Matches Made</CardTitle>
              <ShieldCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{matches.length}</div>
              <p className="text-xs text-muted-foreground">+19% from last month</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
             <CardHeader>
               <CardTitle>Recent Transactions</CardTitle>
             </CardHeader>
             <CardContent>
                <div className="space-y-4">
                  {transactions.slice(0, 5).map(tx => (
                    <div key={tx.id} className="flex items-center justify-between">
                       <div>
                         <p className="text-sm font-medium">{tx.description}</p>
                         <p className="text-xs text-muted-foreground">{new Date(tx.timestamp).toLocaleDateString()}</p>
                       </div>
                       <div className={`font-bold ${tx.type === 'credit' ? 'text-green-500' : 'text-red-500'}`}>
                         {tx.type === 'credit' ? '+' : '-'}{tx.amount}
                       </div>
                    </div>
                  ))}
                  {transactions.length === 0 && <p className="text-muted-foreground text-sm">No transactions yet.</p>}
                </div>
             </CardContent>
          </Card>

          <Card className="bg-primary text-primary-foreground overflow-hidden relative">
             <div className="absolute top-0 right-0 p-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
             <CardHeader>
               <CardTitle>AI System Status</CardTitle>
             </CardHeader>
             <CardContent>
               <div className="flex items-center gap-4 mb-4">
                 <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                 <span className="font-mono text-sm">Operational</span>
               </div>
               <p className="text-sm opacity-90">
                 The Admin AI is monitoring all user interactions for spam and abuse.
                 Last scan completed 2 minutes ago.
               </p>
               <Button variant="secondary" className="mt-6 w-full text-primary" onClick={() => window.location.href = '/admin/ai'}>
                 Open Console
               </Button>
             </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-muted/30">
      <AdminSidebar />
      <div className="pl-64">
        <header className="h-16 border-b bg-card flex items-center px-8 justify-between">
          <h2 className="font-semibold">Dashboard</h2>
          <div className="flex items-center gap-4">
             <div className="text-sm text-right">
               <div className="font-medium">Sunday Ukeme</div>
               <div className="text-xs text-muted-foreground">Super Admin</div>
             </div>
             <Avatar>
               <AvatarFallback>SU</AvatarFallback>
             </Avatar>
          </div>
        </header>
        <main className="p-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Users } from "lucide-react";
