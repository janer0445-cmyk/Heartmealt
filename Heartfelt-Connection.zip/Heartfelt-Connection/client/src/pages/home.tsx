import { useState, useMemo } from "react";
import { useStore } from "@/lib/store";
import { UserCard } from "@/components/user-card";
import { Button } from "@/components/ui/button";
import { Filter, RotateCcw } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { StoryRail } from "@/components/stories/story-rail";

export default function HomePage() {
  const { users, currentUser, likes, dislikes, likeUser, dislikeUser } = useStore();
  const [ageRange, setAgeRange] = useState([18, 50]);
  const [verifiedOnly, setVerifiedOnly] = useState(false);

  const filteredUsers = useMemo(() => {
    if (!currentUser) return [];
    
    const myLikes = likes[currentUser.id] || [];
    const myDislikes = dislikes[currentUser.id] || [];
    
    return users.filter(user => 
      user.id !== currentUser.id &&
      user.role !== 'admin' && // Don't show admin in feed
      !myLikes.includes(user.id) &&
      !myDislikes.includes(user.id) &&
      user.age >= ageRange[0] &&
      user.age <= ageRange[1] &&
      (!verifiedOnly || user.isVerified)
    );
  }, [users, currentUser, likes, dislikes, ageRange, verifiedOnly]);

  const activeUser = filteredUsers[0];

  if (!currentUser) return null;

  return (
    <div className="h-[calc(100vh-64px)] overflow-hidden flex flex-col relative bg-muted/30">
      {/* Header */}
      <header className="px-4 py-4 flex justify-between items-center bg-background/50 backdrop-blur-md sticky top-0 z-10 border-b">
        <h1 className="text-2xl font-heading font-bold text-primary">Spark</h1>
        
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="rounded-full">
              <Filter size={20} />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Filters</SheetTitle>
            </SheetHeader>
            <div className="py-6 space-y-8">
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Label>Age Range</Label>
                  <span className="text-sm text-muted-foreground">{ageRange[0]} - {ageRange[1]}</span>
                </div>
                <Slider
                  defaultValue={[18, 50]}
                  max={100}
                  step={1}
                  value={ageRange}
                  onValueChange={setAgeRange}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label>Verified Only</Label>
                <Switch checked={verifiedOnly} onCheckedChange={setVerifiedOnly} />
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </header>

      {/* Stories */}
      <StoryRail />

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        {activeUser ? (
          <UserCard 
            key={activeUser.id}
            user={activeUser}
            onLike={() => likeUser(activeUser.id)}
            onDislike={() => dislikeUser(activeUser.id)}
          />
        ) : (
          <div className="text-center space-y-4 max-w-xs mx-auto">
            <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <RotateCcw size={40} className="text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold">No more profiles</h3>
            <p className="text-muted-foreground">
              You've seen everyone matching your criteria. Try adjusting your filters.
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setAgeRange([18, 100]);
                setVerifiedOnly(false);
              }}
            >
              Reset Filters
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
