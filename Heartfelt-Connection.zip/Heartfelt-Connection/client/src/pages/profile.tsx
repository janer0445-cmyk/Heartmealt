import { useState } from "react";
import { useStore, User } from "@/lib/store";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Coins, Settings, LogOut, Edit2, Check, Camera, ShieldCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProfilePage() {
  const { currentUser, updateUser, logout } = useStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  
  // Initialize with currentUser or empty object cast to Partial<User>
  const [editForm, setEditForm] = useState<Partial<User>>(currentUser || {});

  if (!currentUser) return null;

  const handleLogout = () => {
    logout();
    setLocation("/auth");
  };

  const handleSave = () => {
    updateUser(editForm);
    setIsEditing(false);
    toast({ title: "Profile updated!" });
  };

  return (
    <div className="pb-24 min-h-screen bg-muted/30">
      {/* Header / Cover */}
      <div className="h-48 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 to-transparent" />
        <div className="absolute top-4 right-4 flex gap-2">
          <Button variant="secondary" size="icon" className="rounded-full bg-white/20 backdrop-blur-md hover:bg-white/30 text-white border-none" onClick={handleLogout}>
            <LogOut size={20} />
          </Button>
        </div>
      </div>

      {/* Profile Content */}
      <div className="px-4 -mt-16 relative">
        <div className="flex justify-between items-end mb-4">
          <div className="relative">
            <Avatar className="w-32 h-32 border-4 border-background shadow-xl">
              <AvatarImage src={currentUser.photos[0]} className="object-cover" />
              <AvatarFallback>{currentUser.name[0]}</AvatarFallback>
            </Avatar>
            {isEditing && (
              <Button size="icon" variant="secondary" className="absolute bottom-0 right-0 rounded-full h-8 w-8 shadow-md">
                <Camera size={14} />
              </Button>
            )}
          </div>
          
          {!isEditing ? (
            <Button onClick={() => setIsEditing(true)} variant="outline" className="rounded-full">
              <Edit2 size={16} className="mr-2" /> Edit Profile
            </Button>
          ) : (
            <Button onClick={handleSave} className="rounded-full">
              <Check size={16} className="mr-2" /> Save
            </Button>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-heading font-bold flex items-center gap-2">
              {currentUser.name}, {currentUser.age}
              {currentUser.isVerified && <ShieldCheck className="text-blue-500" size={24} />}
            </h1>
            <p className="text-muted-foreground flex items-center gap-1">
              {currentUser.location}
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                <Coins className="text-yellow-500 mb-2" size={28} />
                <span className="text-2xl font-bold">{currentUser.coins}</span>
                <span className="text-xs text-muted-foreground">Coins</span>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                <div className="text-2xl font-bold">{currentUser.plan.toUpperCase()}</div>
                <span className="text-xs text-muted-foreground">Current Plan</span>
              </CardContent>
            </Card>
          </div>

          {/* Bio Section */}
          <div className="space-y-2">
            <h3 className="font-bold text-lg">About Me</h3>
            {isEditing ? (
              <Textarea 
                value={editForm.bio || ""} 
                onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                className="min-h-[100px]"
              />
            ) : (
              <p className="text-muted-foreground leading-relaxed">
                {currentUser.bio || "No bio yet."}
              </p>
            )}
          </div>

          {/* Interests */}
          <div className="space-y-2">
            <h3 className="font-bold text-lg">Interests</h3>
            <div className="flex flex-wrap gap-2">
              {currentUser.interests.map((interest, i) => (
                <Badge key={i} variant="secondary" className="px-3 py-1">
                  {interest}
                </Badge>
              ))}
              {isEditing && (
                 <Button variant="outline" size="sm" className="rounded-full h-7 text-xs border-dashed">
                   + Add
                 </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
