import { useState } from "react";
import { useStore } from "@/lib/store";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Users, Music, Gamepad2, Heart, MessageCircle, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function LiveRoomsPage() {
  const { rooms, currentUser, createRoom, joinRoom } = useStore();
  const [newRoomName, setNewRoomName] = useState("");
  const [newRoomCategory, setNewRoomCategory] = useState<'chat' | 'dating' | 'music' | 'gaming'>('chat');
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();

  const handleCreate = () => {
    if (!newRoomName.trim()) return;
    createRoom(newRoomName, newRoomCategory);
    setIsCreating(false);
    toast({ title: "Room Created", description: "Your live room is now active." });
  };

  const getIcon = (cat: string) => {
    switch (cat) {
      case 'music': return <Music size={16} />;
      case 'gaming': return <Gamepad2 size={16} />;
      case 'dating': return <Heart size={16} />;
      default: return <MessageCircle size={16} />;
    }
  };

  return (
    <div className="pb-24 min-h-screen bg-muted/30 p-4 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-heading font-bold">Live Rooms</h1>
          <p className="text-muted-foreground">Join the conversation</p>
        </div>
        
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button className="gap-2 rounded-full">
              <Plus size={18} /> Create Room
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Start a Live Room</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Room Name</Label>
                <Input value={newRoomName} onChange={e => setNewRoomName(e.target.value)} placeholder="e.g. Late Night Chill" />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <RadioGroup value={newRoomCategory} onValueChange={(v: any) => setNewRoomCategory(v)}>
                  <div className="grid grid-cols-2 gap-2">
                    {['chat', 'dating', 'music', 'gaming'].map(cat => (
                      <div key={cat}>
                        <RadioGroupItem value={cat} id={cat} className="peer sr-only" />
                        <Label
                          htmlFor={cat}
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary capitalize cursor-pointer"
                        >
                          {cat}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>
              <Button className="w-full" onClick={handleCreate}>Go Live</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {rooms.map(room => (
          <Card key={room.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer border-none bg-white dark:bg-zinc-900">
            <div className="h-24 bg-gradient-to-r from-primary/80 to-purple-600/80 relative p-4 flex items-start justify-between">
              <Badge className="bg-red-500 border-none animate-pulse">LIVE</Badge>
              <div className="bg-black/20 backdrop-blur text-white px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                <Users size={12} />
                {room.participants.length}
              </div>
            </div>
            <CardContent className="pt-12 relative">
              <div className="absolute -top-8 left-4 border-4 border-background rounded-full bg-muted w-16 h-16 flex items-center justify-center">
                 {getIcon(room.category)}
              </div>
              <div className="mb-4">
                <h3 className="font-bold text-lg">{room.name}</h3>
                <p className="text-sm text-muted-foreground capitalize flex items-center gap-1">
                   {getIcon(room.category)} {room.category}
                </p>
              </div>
              <Button className="w-full" variant="secondary" onClick={() => joinRoom(room.id)}>Join Room</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
