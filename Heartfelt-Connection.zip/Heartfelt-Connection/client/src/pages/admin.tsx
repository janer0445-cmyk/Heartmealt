import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ShieldAlert, ShieldCheck, Download, Trash2, Ban } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function AdminPage() {
  const { currentUser, users, banUser, verifyUser, matches, messages } = useStore();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  if (!currentUser || currentUser.role !== 'admin') {
    setLocation("/");
    return null;
  }

  const exportData = () => {
    const data = JSON.stringify({ users, matches, messages }, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "spark-db-backup.json";
    a.click();
    toast({ title: "Export Complete", description: "Database downloaded successfully." });
  };

  return (
    <div className="min-h-screen bg-muted/30 pb-24 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-heading font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">System Overview & Moderation</p>
          </div>
          <Button onClick={exportData} variant="outline" className="gap-2">
            <Download size={16} /> Backup Data
          </Button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{users.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Matches</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{matches.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Messages Sent</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{messages.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Revenue (Simulated)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$1,240.00</div>
            </CardContent>
          </Card>
        </div>

        {/* User Management */}
        <Card>
          <CardHeader>
            <CardTitle>User Management</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map(user => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-muted overflow-hidden">
                          {user.photos[0] && <img src={user.photos[0]} className="w-full h-full object-cover" />}
                        </div>
                        <div>
                          <div>{user.name}</div>
                          <div className="text-xs text-muted-foreground">{user.email}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {user.isVerified ? (
                        <Badge variant="outline" className="border-green-500 text-green-500 gap-1">
                          <ShieldCheck size={12} /> Verified
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-muted-foreground">Unverified</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.plan === 'gold' ? 'default' : 'secondary'}>
                        {user.plan}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      Today
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      {!user.isVerified && (
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="h-8 w-8 p-0 text-green-600"
                          onClick={() => {
                            verifyUser(user.id);
                            toast({ title: "User Verified" });
                          }}
                        >
                          <ShieldCheck size={14} />
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        variant="destructive" 
                        className="h-8 w-8 p-0"
                        onClick={() => {
                          banUser(user.id);
                          toast({ title: "User Banned" });
                        }}
                      >
                        <Ban size={14} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
