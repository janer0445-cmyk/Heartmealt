import { useState } from "react";
import { useStore } from "@/lib/store";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Coins, Trophy, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function GamesPage() {
  const { games, playGame, currentUser } = useStore();
  const { toast } = useToast();
  const [spinning, setSpinning] = useState<string | null>(null);

  const handlePlay = (gameId: string) => {
    setSpinning(gameId);
    
    // Simulate spin duration
    setTimeout(() => {
      const result = playGame(gameId);
      setSpinning(null);
      
      if (result.won) {
        toast({ 
          title: "🎉 YOU WON!", 
          description: `You won ${result.prize} coins!`,
          className: "bg-yellow-500 text-black border-none"
        });
      } else {
        toast({ 
          title: "Better luck next time", 
          description: "Didn't win this time.", 
          variant: "destructive" 
        });
      }
    }, 2000);
  };

  return (
    <div className="pb-24 min-h-screen bg-muted/30 p-4 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-heading font-bold">Arcade</h1>
          <p className="text-muted-foreground">Play games, earn coins</p>
        </div>
        <div className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full font-bold flex items-center gap-1">
           <Coins size={16} />
           {currentUser?.coins}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {games.map(game => (
          <Card key={game.id} className="overflow-hidden border-none shadow-xl bg-gradient-to-br from-indigo-900 to-purple-900 text-white">
            <CardContent className="p-8 flex flex-col items-center justify-center text-center space-y-6">
               <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center text-4xl mb-2 relative">
                  {spinning === game.id ? (
                     <motion.div 
                       animate={{ rotate: 360 }}
                       transition={{ repeat: Infinity, duration: 0.5, ease: "linear" }}
                     >
                       <Loader2 size={48} />
                     </motion.div>
                  ) : (
                    <span>{game.type === 'wheel' ? '🎡' : '🎰'}</span>
                  )}
               </div>
               
               <div>
                 <h2 className="text-2xl font-bold">{game.name}</h2>
                 <p className="text-white/70">Win up to <span className="text-yellow-400 font-bold">{game.prize}</span> coins!</p>
               </div>

               <Button 
                 size="lg" 
                 className="w-full max-w-xs bg-yellow-500 hover:bg-yellow-400 text-black font-bold text-lg h-14 rounded-full shadow-lg shadow-yellow-500/20"
                 onClick={() => handlePlay(game.id)}
                 disabled={!!spinning}
               >
                 {spinning === game.id ? 'Playing...' : `Play for ${game.cost} Coins`}
               </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
