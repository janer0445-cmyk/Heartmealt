import { useStore } from "@/lib/store";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Coins, CreditCard, History, Wallet as WalletIcon } from "lucide-react";
import { PlanCard } from "@/components/wallet/plan-card";
import { useToast } from "@/hooks/use-toast";

export default function WalletPage() {
  const { currentUser, transactions, upgradePlan, addCoins } = useStore();
  const { toast } = useToast();

  if (!currentUser) return null;

  const handleBuyCoins = (amount: number, cost: number) => {
    // Simulate checkout
    setTimeout(() => {
      addCoins(amount, `Purchased ${amount} coins`);
      toast({ title: "Purchase Successful", description: `Added ${amount} coins to your wallet.` });
    }, 1000);
  };

  const handleConnectFlutterwave = () => {
    toast({
      title: "Connecting Flutterwave...",
      description: "Redirecting to secure payment gateway (Mock)",
      className: "bg-blue-600 text-white border-none"
    });
    // In real app, this would redirect to Flutterwave Oauth or settings
  };

  return (
    <div className="pb-24 min-h-screen bg-muted/30 p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-heading font-bold">Wallet</h1>
        <Button variant="outline" size="sm" className="gap-2" onClick={handleConnectFlutterwave}>
           <CreditCard size={14} /> Connect Flutterwave
        </Button>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-gray-900 to-black text-white border-none shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-24 bg-primary/20 rounded-full blur-3xl -mr-10 -mt-10" />
        <CardContent className="p-6 relative z-10">
          <div className="flex justify-between items-start mb-8">
             <div>
               <p className="text-white/70 text-sm font-medium">Total Balance</p>
               <h2 className="text-4xl font-bold flex items-center gap-2 mt-1">
                 <Coins className="text-yellow-400" fill="currentColor" />
                 {currentUser.coins.toLocaleString()}
               </h2>
             </div>
             <div className="bg-white/10 backdrop-blur px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
               {currentUser.plan} Plan
             </div>
          </div>
          <div className="flex gap-3">
            <Button className="flex-1 bg-white text-black hover:bg-white/90" onClick={() => document.getElementById('plans')?.scrollIntoView({ behavior: 'smooth'})}>
               Upgrade Plan
            </Button>
            <Button className="flex-1 bg-primary text-white hover:bg-primary/90" onClick={() => document.getElementById('coins')?.scrollIntoView({ behavior: 'smooth'})}>
               Add Coins
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Transaction History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History size={20} /> History
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[200px]">
            <div className="p-4 space-y-4">
              {transactions.slice().reverse().map(tx => (
                <div key={tx.id} className="flex justify-between items-center border-b pb-2 last:border-0 last:pb-0">
                  <div>
                    <p className="font-medium text-sm">{tx.description}</p>
                    <p className="text-xs text-muted-foreground">{new Date(tx.timestamp).toLocaleDateString()}</p>
                  </div>
                  <span className={`font-bold ${tx.type === 'credit' ? 'text-green-600' : 'text-red-500'}`}>
                    {tx.type === 'credit' ? '+' : '-'}{tx.amount}
                  </span>
                </div>
              ))}
              {transactions.length === 0 && <p className="text-center text-muted-foreground text-sm">No transactions yet.</p>}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Plans Section */}
      <div id="plans" className="space-y-4">
        <h2 className="text-xl font-bold">Membership Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <PlanCard 
            plan="free" 
            price={0} 
            features={["Basic Matches", "5 Daily Likes", "Standard Support"]} 
            currentPlan={currentUser.plan}
            onUpgrade={() => upgradePlan('free')}
          />
          <PlanCard 
            plan="silver" 
            price={500} 
            features={["Unlimited Likes", "See Who Liked You", "1 Free Boost/mo", "No Ads"]} 
            currentPlan={currentUser.plan}
            onUpgrade={() => upgradePlan('silver')}
          />
          <PlanCard 
            plan="gold" 
            price={1000} 
            features={["All Silver Features", "Priority Matches", "3 Free Boosts/mo", "Travel Mode", "Read Receipts"]} 
            currentPlan={currentUser.plan}
            onUpgrade={() => upgradePlan('gold')}
          />
        </div>
      </div>

      {/* Coins Section */}
      <div id="coins" className="space-y-4">
        <h2 className="text-xl font-bold">Buy Coins</h2>
        <div className="grid grid-cols-2 gap-4">
           {[
             { amount: 100, cost: 4.99 },
             { amount: 500, cost: 19.99 },
             { amount: 1200, cost: 39.99 },
             { amount: 2500, cost: 79.99 },
           ].map((pack, i) => (
             <Card key={i} className="cursor-pointer hover:border-primary transition-colors" onClick={() => handleBuyCoins(pack.amount, pack.cost)}>
               <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                 <Coins size={32} className="text-yellow-400 mb-2" />
                 <div className="text-xl font-bold">{pack.amount} Coins</div>
                 <div className="text-sm text-muted-foreground">${pack.cost}</div>
                 <div className="mt-2 text-xs bg-muted px-2 py-1 rounded">Pay via Flutterwave</div>
               </CardContent>
             </Card>
           ))}
        </div>
      </div>

    </div>
  );
}
