import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useStore } from "@/lib/store";
import { BottomNav } from "@/components/bottom-nav";
import { useEffect } from "react";

import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth";
import HomePage from "@/pages/home";
import ProfilePage from "@/pages/profile";
import MessagesPage from "@/pages/messages";
import WalletPage from "@/pages/wallet";
import LiveRoomsPage from "@/pages/live-rooms";
import GamesPage from "@/pages/games";
import AdminDashboard from "@/pages/admin-dashboard";

function ProtectedRoute({ component: Component, adminOnly = false }: { component: React.ComponentType, adminOnly?: boolean }) {
  const { currentUser } = useStore();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!currentUser) setLocation("/auth");
    if (adminOnly && currentUser && currentUser.role !== 'admin') setLocation("/");
  }, [currentUser, adminOnly, setLocation]);

  if (!currentUser) return null;
  if (adminOnly && currentUser.role !== 'admin') return null;

  return (
    <>
      <Component />
      {!adminOnly && <BottomNav />}
    </>
  );
}

function Router() {
  const { currentUser } = useStore();

  return (
    <Switch>
      <Route path="/auth">
        {currentUser ? (
           currentUser.role === 'admin' ? <Redirect to="/admin" /> : <Redirect to="/" />
        ) : <AuthPage />}
      </Route>
      
      {/* User Routes */}
      <Route path="/">
        <ProtectedRoute component={HomePage} />
      </Route>
      
      <Route path="/profile">
        <ProtectedRoute component={ProfilePage} />
      </Route>
      
      <Route path="/messages">
        <ProtectedRoute component={MessagesPage} />
      </Route>

      <Route path="/wallet">
        <ProtectedRoute component={WalletPage} />
      </Route>
      
      <Route path="/live">
        <ProtectedRoute component={LiveRoomsPage} />
      </Route>
      
      <Route path="/games">
        <ProtectedRoute component={GamesPage} />
      </Route>

      {/* Admin Routes - All point to Dashboard for now, inner routing handled in component */}
      <Route path="/admin">
        <ProtectedRoute component={AdminDashboard} adminOnly />
      </Route>
      <Route path="/admin/ai">
        <ProtectedRoute component={AdminDashboard} adminOnly />
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute component={AdminDashboard} adminOnly />
      </Route>
      <Route path="/admin/finance">
        <ProtectedRoute component={AdminDashboard} adminOnly />
      </Route>
       <Route path="/admin/settings">
        <ProtectedRoute component={AdminDashboard} adminOnly />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
