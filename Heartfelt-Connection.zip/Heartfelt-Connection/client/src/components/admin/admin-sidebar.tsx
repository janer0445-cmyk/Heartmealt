import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Users, 
  Terminal, 
  CreditCard, 
  Settings, 
  LogOut, 
  LayoutDashboard 
} from "lucide-react";
import { useStore } from "@/lib/store";

export function AdminSidebar() {
  const [location, setLocation] = useLocation();
  const { logout } = useStore();

  const handleLogout = () => {
    logout();
    setLocation("/auth");
  };

  const links = [
    { href: "/admin", icon: LayoutDashboard, label: "Overview" },
    { href: "/admin/users", icon: Users, label: "User Management" },
    { href: "/admin/ai", icon: Terminal, label: "AI Console" },
    { href: "/admin/finance", icon: CreditCard, label: "Finance & Plans" },
    { href: "/admin/settings", icon: Settings, label: "System Settings" },
  ];

  return (
    <div className="w-64 bg-card border-r h-screen flex flex-col fixed left-0 top-0">
      <div className="p-6">
        <h1 className="text-2xl font-bold font-heading text-primary">Spark Admin</h1>
        <p className="text-xs text-muted-foreground">Full Control Access</p>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {links.map(link => (
          <Link key={link.href} href={link.href} className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors font-medium",
              location === link.href 
                ? "bg-primary text-primary-foreground" 
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            )}>
              <link.icon size={20} />
              {link.label}
          </Link>
        ))}
      </nav>

      <div className="p-4 border-t">
        <button 
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-destructive hover:bg-destructive/10 w-full font-medium transition-colors"
        >
          <LogOut size={20} />
          Logout
        </button>
      </div>
    </div>
  );
}
