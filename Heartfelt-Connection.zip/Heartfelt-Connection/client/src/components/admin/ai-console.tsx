import { useState, useRef, useEffect } from "react";
import { useStore } from "@/lib/store";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Terminal, Send } from "lucide-react";

export function AIConsole() {
  const { runAdminCommand } = useStore();
  const [history, setHistory] = useState<{type: 'input' | 'output', text: string}[]>([
    { type: 'output', text: 'Admin AI System v1.0 initialized. Waiting for commands...' }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [history]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add user input to history
    setHistory(prev => [...prev, { type: 'input', text: input }]);
    
    // Process command
    const result = runAdminCommand(input);
    
    // Simulate AI thinking delay
    setTimeout(() => {
      setHistory(prev => [...prev, { type: 'output', text: result }]);
    }, 500);

    setInput("");
  };

  return (
    <div className="bg-black rounded-xl overflow-hidden shadow-2xl border border-white/10 font-mono text-sm h-[600px] flex flex-col">
      <div className="bg-white/5 p-3 flex items-center gap-2 border-b border-white/10">
        <Terminal size={16} className="text-green-500" />
        <span className="text-white/70">root@spark-admin:~</span>
      </div>

      <ScrollArea className="flex-1 p-4 bg-black/90">
        <div className="space-y-4">
          {history.map((entry, i) => (
            <div key={i} className={`flex gap-3 ${entry.type === 'input' ? 'text-blue-400' : 'text-green-400'}`}>
              <span className="opacity-50 select-none">
                {entry.type === 'input' ? '>' : '#'}
              </span>
              <span className="whitespace-pre-wrap">{entry.text}</span>
            </div>
          ))}
          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      <form onSubmit={handleSubmit} className="p-4 bg-white/5 border-t border-white/10 flex gap-2">
        <span className="text-blue-400 self-center">{'>'}</span>
        <Input 
          value={input}
          onChange={e => setInput(e.target.value)}
          className="bg-transparent border-none text-white focus-visible:ring-0 font-mono h-auto p-0"
          placeholder="Type a command (e.g., 'ban user Mike', 'give coins 100 to everyone')..."
          autoFocus
        />
        <Button type="submit" size="sm" variant="ghost" className="text-white/50 hover:text-white">
          <Send size={16} />
        </Button>
      </form>
    </div>
  );
}
