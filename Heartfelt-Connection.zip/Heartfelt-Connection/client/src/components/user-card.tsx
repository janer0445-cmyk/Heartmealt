import { useState } from "react";
import { useStore, User } from "@/lib/store";
import { motion, AnimatePresence } from "framer-motion";
import { X, Heart, MapPin, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

interface UserCardProps {
  user: User;
  onLike: () => void;
  onDislike: () => void;
}

export function UserCard({ user, onLike, onDislike }: UserCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div className="relative w-full h-[600px] max-w-sm mx-auto perspective-1000">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0, x: -100 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl bg-black"
      >
        {/* Photo Carousel (Simulated with first photo for now) */}
        <img 
          src={user.photos[0]} 
          alt={user.name}
          className="w-full h-full object-cover pointer-events-none"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/80" />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <div className="flex items-end justify-between mb-2">
            <div>
              <h2 className="text-3xl font-heading font-bold flex items-center gap-2">
                {user.name}, {user.age}
                {user.isVerified && (
                  <Badge variant="secondary" className="bg-blue-500/20 text-blue-200 hover:bg-blue-500/30 border-none">
                    Verified
                  </Badge>
                )}
              </h2>
              <div className="flex items-center gap-1 text-white/80 text-sm mt-1">
                <MapPin size={14} />
                {user.location}
              </div>
            </div>
            <Button 
              size="icon" 
              variant="ghost" 
              className="text-white hover:bg-white/10 rounded-full"
              onClick={() => setShowDetails(!showDetails)}
            >
              <Info size={24} />
            </Button>
          </div>

          {!showDetails && (
            <div className="flex flex-wrap gap-2 mb-20">
              {user.interests.slice(0, 3).map(interest => (
                <Badge key={interest} variant="outline" className="border-white/30 text-white bg-black/20 backdrop-blur-sm">
                  {interest}
                </Badge>
              ))}
            </div>
          )}
          
          <AnimatePresence>
            {showDetails && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden mb-20 space-y-4"
              >
                <p className="text-white/90 leading-relaxed text-sm">
                  {user.bio}
                </p>
                <div className="flex flex-wrap gap-2">
                  {user.interests.map(interest => (
                    <Badge key={interest} variant="secondary" className="bg-white/10 text-white hover:bg-white/20">
                      {interest}
                    </Badge>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Action Buttons */}
        <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-6 z-10">
          <Button
            size="lg"
            variant="outline"
            className="h-16 w-16 rounded-full border-2 border-destructive text-destructive bg-black/20 backdrop-blur-md hover:bg-destructive hover:text-white transition-all shadow-lg"
            onClick={onDislike}
          >
            <X size={32} />
          </Button>
          
          <Button
            size="lg"
            variant="outline"
            className="h-16 w-16 rounded-full border-2 border-green-500 text-green-500 bg-black/20 backdrop-blur-md hover:bg-green-500 hover:text-white transition-all shadow-lg"
            onClick={onLike}
          >
            <Heart size={32} fill="currentColor" className="opacity-0 hover:opacity-100 transition-opacity absolute" />
            <Heart size={32} />
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
