import { useStore } from "@/lib/store";
import { BottomNav } from "./bottom-nav";
import { Toaster } from "@/components/ui/toaster";
import { useEffect } from "react";
import { useLocation } from "wouter";

export function Layout({ children }: { children: React.ReactNode }) {
  const currentUser = useStore(state => state.currentUser);
  const [, setLocation] = useLocation();

  // Protect routes
  useEffect(() => {
    if (!currentUser && window.location.pathname !== '/' && window.location.pathname !== '/auth') {
      setLocation('/');
    }
  }, [currentUser, setLocation]);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <main className="flex-1 pb-20 md:pb-0 md:pl-20">
        {children}
      </main>
      
      {/* Mobile Nav */}
      <div className="md:hidden">
        <BottomNav />
      </div>

      {/* Desktop Sidebar (Hidden on mobile) */}
      <div className="hidden md:flex flex-col fixed left-0 top-0 bottom-0 w-20 border-r border-border bg-card z-50">
        <div className="p-4 flex justify-center">
           <div className="w-8 h-8 rounded-full bg-primary animate-pulse" />
        </div>
        <div className="flex-1 flex flex-col items-center justify-center space-y-8">
           <BottomNavDesktop /> 
        </div>
      </div>
      
      <Toaster />
    </div>
  );
}

// Re-using logic for desktop specific sidebar just for visual clarity
import { Home, MessageCircle, User, Heart, Shield } from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

function BottomNavDesktop() {
  const [location] = useLocation();
  const currentUser = useStore(state => state.currentUser);
  
  if (!currentUser) return null;

  const links = [
    { href: "/home", icon: Home, label: "Discover" },
    { href: "/matches", icon: Heart, label: "Matches" },
    { href: "/messages", icon: MessageCircle, label: "Chat" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  if (currentUser.role === 'admin') {
    links.push({ href: "/admin", icon: Shield, label: "Admin" });
  }

  return (
    <>
        {links.map((link) => {
          const isActive = location === link.href;
          return (
            <Link key={link.href} href={link.href}>
              <a className={cn(
                "flex flex-col items-center justify-center w-12 h-12 rounded-xl transition-all duration-200 hover:bg-muted",
                isActive ? "text-primary bg-primary/10" : "text-muted-foreground"
              )}>
                <link.icon className={cn("w-6 h-6", isActive && "fill-current")} />
              </a>
            </Link>
          );
        })}
    </>
  );
}
