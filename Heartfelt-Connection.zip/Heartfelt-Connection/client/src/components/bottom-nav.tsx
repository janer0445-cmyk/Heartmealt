import { Link, useLocation } from "wouter";
import { Home, MessageCircle, User, Wallet, Gamepad2, Radio } from "lucide-react";
import { cn } from "@/lib/utils";
import { useStore } from "@/lib/store";

export function BottomNav() {
  const [location] = useLocation();
  const { currentUser } = useStore();

  if (!currentUser || currentUser.role === 'admin') return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/90 dark:bg-black/90 backdrop-blur-lg border-t border-border pb-safe">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto px-2">
        <Link href="/" className={cn("flex flex-col items-center gap-1 transition-colors min-w-[50px]", location === "/" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Home size={22} />
            <span className="text-[10px] font-medium">Feed</span>
        </Link>
        
        <Link href="/live" className={cn("flex flex-col items-center gap-1 transition-colors min-w-[50px]", location === "/live" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Radio size={22} />
            <span className="text-[10px] font-medium">Live</span>
        </Link>

        <Link href="/games" className={cn("flex flex-col items-center gap-1 transition-colors min-w-[50px]", location === "/games" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Gamepad2 size={22} />
            <span className="text-[10px] font-medium">Games</span>
        </Link>
        
        <Link href="/messages" className={cn("flex flex-col items-center gap-1 transition-colors min-w-[50px]", location === "/messages" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <MessageCircle size={22} />
            <span className="text-[10px] font-medium">Chats</span>
        </Link>

        <Link href="/wallet" className={cn("flex flex-col items-center gap-1 transition-colors min-w-[50px]", location === "/wallet" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <Wallet size={22} />
            <span className="text-[10px] font-medium">Wallet</span>
        </Link>

        <Link href="/profile" className={cn("flex flex-col items-center gap-1 transition-colors min-w-[50px]", location === "/profile" ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
            <User size={22} />
            <span className="text-[10px] font-medium">Me</span>
        </Link>
      </div>
    </nav>
  );
}
