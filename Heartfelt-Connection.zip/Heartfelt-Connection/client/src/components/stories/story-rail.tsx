import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus } from "lucide-react";
import { useStore } from "@/lib/store";

export function StoryRail() {
  const { stories, users, currentUser } = useStore();
  
  // Group stories by user, only show active ones
  const activeStories = stories.filter(s => new Date(s.expiresAt) > new Date());
  
  // Get unique users who have stories
  const storyUserIds = Array.from(new Set(activeStories.map(s => s.userId)));
  
  return (
    <div className="py-4 border-b bg-background/50 backdrop-blur-sm">
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex w-max space-x-4 px-4">
          {/* Add Story Button */}
          <div className="flex flex-col items-center gap-1 cursor-pointer">
            <div className="w-16 h-16 rounded-full border-2 border-dashed border-muted-foreground/50 flex items-center justify-center bg-muted/30 hover:bg-muted/50 transition-colors">
              <Plus className="text-muted-foreground" />
            </div>
            <span className="text-xs font-medium">Add Story</span>
          </div>

          {/* User Stories */}
          {storyUserIds.map(userId => {
             const user = users.find(u => u.id === userId);
             if (!user || user.id === currentUser?.id) return null; // Skip self in this list for now
             
             return (
               <div key={userId} className="flex flex-col items-center gap-1 cursor-pointer">
                 <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-yellow-400 to-primary">
                   <Avatar className="w-full h-full border-2 border-background">
                     <AvatarImage src={user.photos[0]} />
                     <AvatarFallback>{user.name[0]}</AvatarFallback>
                   </Avatar>
                 </div>
                 <span className="text-xs font-medium">{user.name}</span>
               </div>
             );
          })}
        </div>
        <ScrollBar orientation="horizontal" className="invisible" />
      </ScrollArea>
    </div>
  );
}
