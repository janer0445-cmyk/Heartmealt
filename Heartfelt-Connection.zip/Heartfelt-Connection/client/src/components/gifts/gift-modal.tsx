import { useState } from "react";
import { useStore, Gift } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Gift as GiftIcon, Coins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GiftModalProps {
  receiverId: string;
  trigger?: React.ReactNode;
}

export function GiftModal({ receiverId, trigger }: GiftModalProps) {
  const { gifts, sendGift, currentUser } = useStore();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);

  const handleSend = (gift: Gift) => {
    if (sendGift(receiverId, gift.id)) {
      toast({ title: "Gift Sent!", description: `You sent a ${gift.name}.` });
      setOpen(false);
    } else {
      toast({ title: "Failed", description: "Not enough coins.", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button size="icon" variant="ghost">
            <GiftIcon size={20} />
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Send a Gift</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-3 gap-4 py-4">
          {gifts.map(gift => (
             <button
               key={gift.id}
               className="flex flex-col items-center p-4 rounded-xl border hover:border-primary hover:bg-primary/5 transition-all gap-2"
               onClick={() => handleSend(gift)}
             >
               <span className="text-4xl">{gift.icon}</span>
               <span className="font-medium text-sm">{gift.name}</span>
               <div className="flex items-center gap-1 text-xs text-yellow-600 font-bold bg-yellow-100 px-2 py-0.5 rounded-full">
                 <Coins size={10} />
                 {gift.cost}
               </div>
             </button>
          ))}
        </div>
        <div className="flex justify-between items-center text-sm text-muted-foreground border-t pt-4">
           <span>Your Balance:</span>
           <span className="font-bold flex items-center gap-1 text-foreground">
             <Coins size={14} className="text-yellow-500" />
             {currentUser?.coins}
           </span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
