import { User, Plan } from "@/lib/store";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

interface PlanCardProps {
  plan: Plan;
  price: number;
  features: string[];
  currentPlan: Plan;
  onUpgrade: () => void;
}

export function PlanCard({ plan, price, features, currentPlan, onUpgrade }: PlanCardProps) {
  const isCurrent = currentPlan === plan;
  const isFree = plan === 'free';

  return (
    <Card className={`relative overflow-hidden transition-all hover:scale-105 ${isCurrent ? 'border-primary shadow-lg shadow-primary/20' : ''}`}>
      {isCurrent && (
        <div className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg font-bold">
          CURRENT
        </div>
      )}
      
      <CardHeader className="text-center pb-2">
        <CardTitle className="capitalize text-2xl font-bold">{plan}</CardTitle>
        <div className="text-3xl font-bold mt-2">
          {isFree ? 'Free' : (
            <span className="flex items-center justify-center gap-1">
              <span className="text-yellow-500 text-lg">🪙</span>
              {price}
            </span>
          )}
        </div>
        <div className="text-sm text-muted-foreground">{isFree ? 'Forever' : 'per month'}</div>
      </CardHeader>
      
      <CardContent>
        <ul className="space-y-3">
          {features.map((feature, i) => (
            <li key={i} className="flex items-start gap-2 text-sm">
              <Check size={16} className="text-green-500 mt-0.5 shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>

      <CardFooter>
        <Button 
          className="w-full" 
          variant={isCurrent ? "outline" : "default"}
          disabled={isCurrent}
          onClick={onUpgrade}
        >
          {isCurrent ? "Active Plan" : isFree ? "Downgrade" : "Upgrade"}
        </Button>
      </CardFooter>
    </Card>
  );
}
