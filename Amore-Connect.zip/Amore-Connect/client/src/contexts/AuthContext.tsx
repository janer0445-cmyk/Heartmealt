import { createContext, useContext, useState, useEffect } from "react";
import type { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  signup: (data: SignupData) => Promise<boolean>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  selectSubscription: (planId: string) => Promise<boolean>;
  refreshUser: () => Promise<void>;
}

interface SignupData {
  username: string;
  email: string;
  password: string;
  displayName: string;
  age: number;
  gender: string;
  ageConfirmed: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("sparkmatch-user");
    if (stored) {
      try {
        const parsedUser = JSON.parse(stored);
        setUser(parsedUser);
        refreshUserFromServer(parsedUser.id);
      } catch {
        localStorage.removeItem("sparkmatch-user");
      }
    }
    setIsLoading(false);
  }, []);

  const refreshUserFromServer = async (userId: string) => {
    try {
      const response = await fetch(`/api/users/${userId}`);
      if (response.ok) {
        const serverUser = await response.json();
        setUser(serverUser);
        localStorage.setItem("sparkmatch-user", JSON.stringify(serverUser));
      }
    } catch {
      // Silently fail, use cached data
    }
  };

  const refreshUser = async () => {
    if (user?.id) {
      await refreshUserFromServer(user.id);
    }
  };

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      const response = await apiRequest("POST", "/api/auth/login", { username, password });
      const data = await response.json();
      if (data.user) {
        setUser(data.user);
        localStorage.setItem("sparkmatch-user", JSON.stringify(data.user));
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const signup = async (data: SignupData): Promise<boolean> => {
    try {
      const response = await apiRequest("POST", "/api/auth/signup", data);
      const result = await response.json();
      if (result.user) {
        setUser(result.user);
        localStorage.setItem("sparkmatch-user", JSON.stringify(result.user));
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("sparkmatch-user");
  };

  const updateUser = async (updates: Partial<User>) => {
    if (user) {
      // Optimistic update
      const updated = { ...user, ...updates };
      setUser(updated);
      localStorage.setItem("sparkmatch-user", JSON.stringify(updated));
      
      // Sync to server
      try {
        await apiRequest("PATCH", `/api/users/${user.id}`, updates);
      } catch {
        // If server update fails, we still keep the local state
        console.error("Failed to sync user update to server");
      }
    }
  };

  const selectSubscription = async (planId: string): Promise<boolean> => {
    if (!user) return false;
    try {
      const response = await apiRequest("POST", "/api/subscriptions/select", { 
        userId: user.id, 
        planId 
      });
      const data = await response.json();
      if (data.user) {
        setUser(data.user);
        localStorage.setItem("sparkmatch-user", JSON.stringify(data.user));
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isLoading, 
      isAuthenticated: !!user, 
      login, 
      signup, 
      logout, 
      updateUser,
      selectSubscription,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
