import { BottomNav } from "./BottomNav";
import { TopBar } from "./TopBar";

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
  showTopBar?: boolean;
  showBottomNav?: boolean;
  showCoins?: boolean;
}

export function AppLayout({ 
  children, 
  title,
  showTopBar = true,
  showBottomNav = true,
  showCoins = true
}: AppLayoutProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {showTopBar && <TopBar title={title} showCoins={showCoins} />}
      <main className={`flex-1 ${showBottomNav ? "pb-20" : ""}`}>
        {children}
      </main>
      {showBottomNav && <BottomNav />}
    </div>
  );
}
