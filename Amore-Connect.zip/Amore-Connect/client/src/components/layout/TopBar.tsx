import { Bell, Settings, Coins, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";

interface TopBarProps {
  title?: string;
  showCoins?: boolean;
  showNotifications?: boolean;
  showSettings?: boolean;
}

export function TopBar({ 
  title = "SparkMatch", 
  showCoins = true, 
  showNotifications = true,
  showSettings = false 
}: TopBarProps) {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <header 
      className="sticky top-0 z-40 bg-background/95 backdrop-blur-lg border-b border-border"
      data-testid="header-top"
    >
      <div className="flex items-center justify-between h-14 px-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-pink-400 bg-clip-text text-transparent">
            {title}
          </h1>
        </div>

        <div className="flex items-center gap-1">
          {showCoins && user && (
            <Link href="/coins">
              <Button variant="ghost" size="sm" className="gap-1.5" data-testid="button-coins">
                <Coins className="w-4 h-4 text-yellow-500" />
                <span className="font-semibold text-sm">{user.coins || 0}</span>
              </Button>
            </Link>
          )}

          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
          >
            {theme === "dark" ? (
              <Sun className="w-5 h-5" />
            ) : (
              <Moon className="w-5 h-5" />
            )}
          </Button>

          {showNotifications && (
            <Link href="/notifications">
              <Button variant="ghost" size="icon" className="relative" data-testid="button-notifications">
                <Bell className="w-5 h-5" />
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center text-[10px]"
                >
                  3
                </Badge>
              </Button>
            </Link>
          )}

          {showSettings && (
            <Link href="/settings">
              <Button variant="ghost" size="icon" data-testid="button-settings">
                <Settings className="w-5 h-5" />
              </Button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
