import { useLocation, Link } from "wouter";
import { Home, Search, MessageCircle, BookOpen, User } from "lucide-react";

const navItems = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/discover", icon: Search, label: "Discover" },
  { path: "/messages", icon: MessageCircle, label: "Messages" },
  { path: "/stories", icon: BookOpen, label: "Stories" },
  { path: "/profile", icon: User, label: "Profile" },
];

export function BottomNav() {
  const [location] = useLocation();

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-lg border-t border-border"
      data-testid="nav-bottom"
    >
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto px-2">
        {navItems.map((item) => {
          const isActive = location === item.path || 
            (item.path !== "/" && location.startsWith(item.path));
          const Icon = item.icon;
          
          return (
            <Link key={item.path} href={item.path}>
              <button
                className={`flex flex-col items-center justify-center w-16 h-14 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? "text-primary" 
                    : "text-muted-foreground"
                }`}
                data-testid={`nav-${item.label.toLowerCase()}`}
              >
                <div className={`p-2 rounded-xl transition-all duration-200 ${
                  isActive ? "bg-primary/10" : ""
                }`}>
                  <Icon className="w-5 h-5" strokeWidth={isActive ? 2.5 : 2} />
                </div>
                <span className="text-[10px] font-medium mt-0.5">{item.label}</span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
