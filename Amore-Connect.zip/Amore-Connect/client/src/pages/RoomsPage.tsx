import { useState } from "react";
import { Link } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Radio, 
  Users, 
  Plus, 
  Mic, 
  MicOff, 
  LogOut,
  Search,
  MessageCircle,
  Send
} from "lucide-react";

const rooms = [
  {
    id: "1",
    name: "Speed Dating Night",
    topic: "Find your match in 5 minutes!",
    hostId: "1",
    hostName: "Sarah",
    hostPhoto: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    participants: 45,
    maxParticipants: 50,
    isLive: true,
    participantPhotos: [
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    ],
  },
  {
    id: "2",
    name: "Single & Ready to Mingle",
    topic: "Casual chat for singles",
    hostId: "2",
    hostName: "Mike",
    hostPhoto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    participants: 23,
    maxParticipants: 30,
    isLive: true,
    participantPhotos: [
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
    ],
  },
  {
    id: "3",
    name: "Movie Lovers Unite",
    topic: "Discuss your favorite films",
    hostId: "3",
    hostName: "Emma",
    hostPhoto: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
    participants: 18,
    maxParticipants: 25,
    isLive: true,
    participantPhotos: [
      "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150",
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150",
    ],
  },
];

const roomMessages = [
  { id: "1", userId: "2", userName: "Mike", content: "Hey everyone! Welcome to the room!", timestamp: "10:30" },
  { id: "2", userId: "3", userName: "Emma", content: "Thanks for having us!", timestamp: "10:31" },
  { id: "3", userId: "4", userName: "Jake", content: "This is so fun!", timestamp: "10:32" },
  { id: "4", userId: "1", userName: "Sarah", content: "Let's get the party started!", timestamp: "10:33" },
];

export default function RoomsPage() {
  const [activeRoom, setActiveRoom] = useState<typeof rooms[0] | null>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState(roomMessages);
  const [createOpen, setCreateOpen] = useState(false);
  const [newRoom, setNewRoom] = useState({ name: "", topic: "" });
  const { toast } = useToast();

  const handleJoin = (room: typeof rooms[0]) => {
    setActiveRoom(room);
    toast({ title: "Joined Room", description: `You joined ${room.name}` });
  };

  const handleLeave = () => {
    setActiveRoom(null);
    toast({ title: "Left Room", description: "You left the room" });
  };

  const handleSendMessage = () => {
    if (!message.trim()) return;
    setMessages([
      ...messages,
      {
        id: Date.now().toString(),
        userId: "me",
        userName: "You",
        content: message,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
    setMessage("");
  };

  const handleCreateRoom = () => {
    if (!newRoom.name) {
      toast({ title: "Error", description: "Please enter a room name", variant: "destructive" });
      return;
    }
    toast({ title: "Room Created!", description: `Your room "${newRoom.name}" is now live` });
    setCreateOpen(false);
    setNewRoom({ name: "", topic: "" });
  };

  if (activeRoom) {
    return (
      <div className="flex flex-col h-screen bg-background">
        <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-lg border-b border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge variant="destructive" className="animate-pulse">LIVE</Badge>
              <div>
                <h2 className="font-semibold">{activeRoom.name}</h2>
                <p className="text-xs text-muted-foreground">{activeRoom.participants} participants</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setIsMuted(!isMuted)}
                data-testid="button-mute"
              >
                {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
              <Button 
                variant="destructive" 
                size="icon"
                onClick={handleLeave}
                data-testid="button-leave"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
            <div className="flex flex-col items-center gap-1">
              <Avatar className="w-12 h-12 ring-2 ring-primary">
                <AvatarImage src={activeRoom.hostPhoto} />
                <AvatarFallback>{activeRoom.hostName[0]}</AvatarFallback>
              </Avatar>
              <span className="text-xs">Host</span>
            </div>
            {activeRoom.participantPhotos.map((photo, i) => (
              <div key={i} className="flex flex-col items-center gap-1">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={photo} />
                  <AvatarFallback>U</AvatarFallback>
                </Avatar>
              </div>
            ))}
            <div className="flex flex-col items-center gap-1">
              <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                +{activeRoom.participants - 4}
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((msg) => (
            <div key={msg.id} className="flex items-start gap-2" data-testid={`room-message-${msg.id}`}>
              <Avatar className="w-8 h-8">
                <AvatarFallback>{msg.userName[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm">{msg.userName}</span>
                  <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                </div>
                <p className="text-sm">{msg.content}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="sticky bottom-0 bg-background border-t border-border p-4">
          <div className="flex items-center gap-2">
            <Input
              placeholder="Say something..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              className="flex-1"
              data-testid="input-room-message"
            />
            <Button 
              size="icon" 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              data-testid="button-send-room"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <AppLayout title="Live Rooms">
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search rooms..." 
              className="pl-10"
              data-testid="input-search-rooms"
            />
          </div>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2" data-testid="button-create-room">
                <Plus className="w-4 h-4" /> Create
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Live Room</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Room Name</label>
                  <Input
                    placeholder="e.g., Friday Night Chat"
                    value={newRoom.name}
                    onChange={(e) => setNewRoom({ ...newRoom, name: e.target.value })}
                    data-testid="input-room-name"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Topic (optional)</label>
                  <Input
                    placeholder="What's this room about?"
                    value={newRoom.topic}
                    onChange={(e) => setNewRoom({ ...newRoom, topic: e.target.value })}
                    data-testid="input-room-topic"
                  />
                </div>
                <Button onClick={handleCreateRoom} className="w-full" data-testid="button-create-room-submit">
                  Go Live
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="space-y-3">
          {rooms.map((room) => (
            <Card key={room.id} className="overflow-hidden" data-testid={`room-${room.id}`}>
              <div className="relative h-32 bg-gradient-to-br from-purple-600 to-pink-500">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white">
                    <Badge variant="destructive" className="mb-2 animate-pulse">
                      <Radio className="w-3 h-3 mr-1" /> LIVE
                    </Badge>
                    <p className="font-bold text-lg">{room.name}</p>
                    <p className="text-sm opacity-90">{room.topic}</p>
                  </div>
                </div>
              </div>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={room.hostPhoto} />
                      <AvatarFallback>{room.hostName[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Hosted by {room.hostName}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {room.participants}/{room.maxParticipants} participants
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {room.participantPhotos.slice(0, 3).map((photo, i) => (
                        <Avatar key={i} className="w-8 h-8 border-2 border-background">
                          <AvatarImage src={photo} />
                          <AvatarFallback>U</AvatarFallback>
                        </Avatar>
                      ))}
                    </div>
                    <Button 
                      size="sm"
                      onClick={() => handleJoin(room)}
                      data-testid={`button-join-${room.id}`}
                    >
                      Join
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
