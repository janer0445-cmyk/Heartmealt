import { Link } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, Check, CheckCheck } from "lucide-react";

const conversations = [
  {
    id: "1",
    name: "Sarah",
    photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    lastMessage: "Hey! Would love to grab coffee sometime",
    timestamp: "2m ago",
    unread: 2,
    online: true,
    isRead: false,
  },
  {
    id: "2",
    name: "Mike",
    photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    lastMessage: "That sounds great! When are you free?",
    timestamp: "1h ago",
    unread: 0,
    online: false,
    isRead: true,
  },
  {
    id: "3",
    name: "Emma",
    photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
    lastMessage: "I loved that restaurant you recommended!",
    timestamp: "3h ago",
    unread: 0,
    online: true,
    isRead: true,
  },
  {
    id: "4",
    name: "Jake",
    photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    lastMessage: "Let's do that hiking trip next weekend",
    timestamp: "1d ago",
    unread: 0,
    online: false,
    isRead: true,
  },
  {
    id: "5",
    name: "Lisa",
    photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
    lastMessage: "You matched! Start the conversation",
    timestamp: "2d ago",
    unread: 1,
    online: true,
    isRead: false,
    isNew: true,
  },
];

export default function MessagesPage() {
  return (
    <AppLayout title="Messages">
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search conversations..." 
            className="pl-10"
            data-testid="input-search-messages"
          />
        </div>

        <div className="space-y-2">
          {conversations.map((convo) => (
            <Link key={convo.id} href={`/chat/${convo.id}`}>
              <Card 
                className={`hover-elevate cursor-pointer ${convo.unread > 0 ? "bg-primary/5" : ""}`}
                data-testid={`conversation-${convo.id}`}
              >
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="relative">
                    <Avatar className="w-14 h-14">
                      <AvatarImage src={convo.photoUrl} />
                      <AvatarFallback>{convo.name[0]}</AvatarFallback>
                    </Avatar>
                    {convo.online && (
                      <div className="absolute bottom-0 right-0 w-4 h-4 bg-status-online rounded-full border-2 border-background" />
                    )}
                    {convo.unread > 0 && (
                      <Badge 
                        className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-[10px]"
                      >
                        {convo.unread}
                      </Badge>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className={`font-semibold truncate ${convo.unread > 0 ? "text-foreground" : ""}`}>
                        {convo.name}
                      </h3>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {convo.timestamp}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      {!convo.isNew && (
                        <span className="shrink-0">
                          {convo.isRead ? (
                            <CheckCheck className="w-4 h-4 text-primary" />
                          ) : (
                            <Check className="w-4 h-4 text-muted-foreground" />
                          )}
                        </span>
                      )}
                      <p className={`text-sm truncate ${convo.unread > 0 ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                        {convo.isNew ? (
                          <span className="text-primary font-medium">{convo.lastMessage}</span>
                        ) : (
                          convo.lastMessage
                        )}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {conversations.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold mb-1">No messages yet</h3>
            <p className="text-sm text-muted-foreground">
              Start swiping to find your match!
            </p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
