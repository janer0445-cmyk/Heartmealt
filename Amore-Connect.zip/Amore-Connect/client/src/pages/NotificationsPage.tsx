import { useState } from "react";
import { Link } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Heart, 
  MessageCircle, 
  Gift, 
  Users, 
  Bell, 
  Check,
  Gamepad2,
  Crown
} from "lucide-react";

const notifications = [
  {
    id: "1",
    type: "match",
    title: "New Match!",
    message: "You and Sarah matched! Start a conversation.",
    photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    timestamp: "2m ago",
    isRead: false,
    href: "/chat/1",
  },
  {
    id: "2",
    type: "message",
    title: "New Message",
    message: "Mike sent you a message",
    photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    timestamp: "15m ago",
    isRead: false,
    href: "/chat/2",
  },
  {
    id: "3",
    type: "gift",
    title: "Gift Received!",
    message: "Emma sent you a Rose",
    photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
    timestamp: "1h ago",
    isRead: true,
    href: "/gifts",
  },
  {
    id: "4",
    type: "friend",
    title: "Friend Request",
    message: "Jake wants to be your friend",
    photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    timestamp: "2h ago",
    isRead: true,
    href: "/friends",
  },
  {
    id: "5",
    type: "game",
    title: "Game Invite",
    message: "Lisa invited you to play Trivia Night",
    photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
    timestamp: "3h ago",
    isRead: true,
    href: "/games",
  },
  {
    id: "6",
    type: "subscription",
    title: "Subscription Active",
    message: "Your Gold membership is now active!",
    photoUrl: null,
    timestamp: "1d ago",
    isRead: true,
    href: "/subscription",
  },
];

const iconMap: Record<string, typeof Heart> = {
  match: Heart,
  message: MessageCircle,
  gift: Gift,
  friend: Users,
  game: Gamepad2,
  subscription: Crown,
};

const colorMap: Record<string, string> = {
  match: "text-pink-500 bg-pink-500/10",
  message: "text-blue-500 bg-blue-500/10",
  gift: "text-red-500 bg-red-500/10",
  friend: "text-green-500 bg-green-500/10",
  game: "text-orange-500 bg-orange-500/10",
  subscription: "text-yellow-500 bg-yellow-500/10",
};

export default function NotificationsPage() {
  const [items, setItems] = useState(notifications);

  const handleMarkAllRead = () => {
    setItems(items.map(item => ({ ...item, isRead: true })));
  };

  const unreadCount = items.filter(n => !n.isRead).length;

  return (
    <AppLayout title="Notifications">
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-muted-foreground text-sm">
            {unreadCount > 0 ? `${unreadCount} unread` : "All caught up!"}
          </p>
          {unreadCount > 0 && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="gap-2"
              onClick={handleMarkAllRead}
              data-testid="button-mark-all-read"
            >
              <Check className="w-4 h-4" /> Mark all read
            </Button>
          )}
        </div>

        <div className="space-y-2">
          {items.map((notification) => {
            const Icon = iconMap[notification.type] || Bell;
            const colorClass = colorMap[notification.type] || "text-muted-foreground bg-muted";
            
            return (
              <Link key={notification.id} href={notification.href}>
                <Card 
                  className={`hover-elevate cursor-pointer ${!notification.isRead ? "bg-primary/5" : ""}`}
                  data-testid={`notification-${notification.id}`}
                >
                  <CardContent className="flex items-start gap-4 p-4">
                    {notification.photoUrl ? (
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={notification.photoUrl} />
                        <AvatarFallback>{notification.title[0]}</AvatarFallback>
                      </Avatar>
                    ) : (
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${colorClass}`}>
                        <Icon className="w-6 h-6" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className={`font-semibold text-sm ${!notification.isRead ? "text-foreground" : ""}`}>
                          {notification.title}
                        </h3>
                        <span className="text-xs text-muted-foreground shrink-0">
                          {notification.timestamp}
                        </span>
                      </div>
                      <p className={`text-sm ${!notification.isRead ? "text-foreground" : "text-muted-foreground"}`}>
                        {notification.message}
                      </p>
                    </div>
                    {!notification.isRead && (
                      <div className="w-2 h-2 rounded-full bg-primary shrink-0 mt-2" />
                    )}
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        {items.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Bell className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold mb-1">No notifications</h3>
            <p className="text-sm text-muted-foreground">
              You're all caught up!
            </p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
