import { useState } from "react";
import { Link } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  UserPlus, 
  Check, 
  X, 
  MessageCircle,
  Users,
  Clock,
  UserCheck
} from "lucide-react";

const friends = [
  { id: "1", name: "Sarah", photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150", online: true, mutualFriends: 5 },
  { id: "2", name: "Mike", photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150", online: false, mutualFriends: 3 },
  { id: "3", name: "Emma", photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150", online: true, mutualFriends: 8 },
];

const pendingRequests = [
  { id: "4", name: "Jake", photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150", mutualFriends: 2 },
  { id: "5", name: "Lisa", photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150", mutualFriends: 4 },
];

const suggestions = [
  { id: "6", name: "Tom", photoUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150", mutualFriends: 6 },
  { id: "7", name: "Amy", photoUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150", mutualFriends: 3 },
  { id: "8", name: "Chris", photoUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150", mutualFriends: 7 },
];

export default function FriendsPage() {
  const [activeTab, setActiveTab] = useState("friends");
  const { toast } = useToast();

  const handleAccept = (name: string) => {
    toast({ title: "Friend Added!", description: `You and ${name} are now friends` });
  };

  const handleDecline = (name: string) => {
    toast({ title: "Request Declined", description: `Friend request from ${name} declined` });
  };

  const handleAddFriend = (name: string) => {
    toast({ title: "Request Sent!", description: `Friend request sent to ${name}` });
  };

  return (
    <AppLayout title="Friends">
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search friends..." 
            className="pl-10"
            data-testid="input-search-friends"
          />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="friends" className="gap-2" data-testid="tab-friends">
              <UserCheck className="w-4 h-4" />
              Friends
            </TabsTrigger>
            <TabsTrigger value="requests" className="gap-2" data-testid="tab-requests">
              <Clock className="w-4 h-4" />
              Requests
              {pendingRequests.length > 0 && (
                <Badge className="ml-1 h-5 w-5 p-0 flex items-center justify-center">
                  {pendingRequests.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="suggestions" className="gap-2" data-testid="tab-suggestions">
              <Users className="w-4 h-4" />
              Discover
            </TabsTrigger>
          </TabsList>

          <TabsContent value="friends" className="space-y-3 mt-4">
            {friends.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
                  <Users className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-semibold mb-1">No friends yet</h3>
                <p className="text-sm text-muted-foreground">
                  Start discovering people to connect with!
                </p>
              </div>
            ) : (
              friends.map((friend) => (
                <Card key={friend.id} className="hover-elevate" data-testid={`friend-${friend.id}`}>
                  <CardContent className="flex items-center gap-4 p-4">
                    <div className="relative">
                      <Avatar className="w-14 h-14">
                        <AvatarImage src={friend.photoUrl} />
                        <AvatarFallback>{friend.name[0]}</AvatarFallback>
                      </Avatar>
                      {friend.online && (
                        <div className="absolute bottom-0 right-0 w-4 h-4 bg-status-online rounded-full border-2 border-background" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold">{friend.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {friend.mutualFriends} mutual friends
                      </p>
                    </div>
                    <Link href={`/chat/${friend.id}`}>
                      <Button variant="outline" size="icon" data-testid={`button-message-${friend.id}`}>
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="requests" className="space-y-3 mt-4">
            {pendingRequests.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
                  <Clock className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-semibold mb-1">No pending requests</h3>
                <p className="text-sm text-muted-foreground">
                  You're all caught up!
                </p>
              </div>
            ) : (
              pendingRequests.map((request) => (
                <Card key={request.id} data-testid={`request-${request.id}`}>
                  <CardContent className="flex items-center gap-4 p-4">
                    <Avatar className="w-14 h-14">
                      <AvatarImage src={request.photoUrl} />
                      <AvatarFallback>{request.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold">{request.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {request.mutualFriends} mutual friends
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="icon" 
                        onClick={() => handleAccept(request.name)}
                        data-testid={`button-accept-${request.id}`}
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => handleDecline(request.name)}
                        data-testid={`button-decline-${request.id}`}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="suggestions" className="space-y-3 mt-4">
            {suggestions.map((person) => (
              <Card key={person.id} className="hover-elevate" data-testid={`suggestion-${person.id}`}>
                <CardContent className="flex items-center gap-4 p-4">
                  <Avatar className="w-14 h-14">
                    <AvatarImage src={person.photoUrl} />
                    <AvatarFallback>{person.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-semibold">{person.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {person.mutualFriends} mutual friends
                    </p>
                  </div>
                  <Button 
                    size="sm" 
                    className="gap-2"
                    onClick={() => handleAddFriend(person.name)}
                    data-testid={`button-add-${person.id}`}
                  >
                    <UserPlus className="w-4 h-4" /> Add
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
