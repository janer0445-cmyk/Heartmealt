import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Users, 
  CreditCard, 
  Coins, 
  Gift, 
  Gamepad2, 
  Radio, 
  Settings, 
  LogOut,
  Send,
  Bot,
  Search,
  Edit,
  Trash2,
  Plus,
  TrendingUp,
  Eye,
  Ban,
  Check,
  Moon,
  Sun,
  Palette
} from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";

const mockUsers = [
  { id: "1", username: "sarah_j", displayName: "Sarah", email: "sarah@example.com", plan: "gold", coins: 500, status: "active" },
  { id: "2", username: "mike_t", displayName: "Mike", email: "mike@example.com", plan: "silver", coins: 250, status: "active" },
  { id: "3", username: "emma_w", displayName: "Emma", email: "emma@example.com", plan: "free", coins: 50, status: "active" },
  { id: "4", username: "jake_r", displayName: "Jake", email: "jake@example.com", plan: "gold", coins: 800, status: "suspended" },
];

const mockGifts = [
  { id: "rose", name: "Rose", price: 10, active: true },
  { id: "heart", name: "Heart", price: 15, active: true },
  { id: "star", name: "Star", price: 20, active: true },
  { id: "crown", name: "Crown", price: 200, active: true },
];

const mockAuditLogs = [
  { id: "1", action: "User banned", details: "jake_r suspended for policy violation", timestamp: "2m ago" },
  { id: "2", action: "Gift price updated", details: "Crown price changed from 150 to 200", timestamp: "1h ago" },
  { id: "3", action: "Feature toggled", details: "Games feature enabled", timestamp: "2h ago" },
  { id: "4", action: "AI Command", details: "Theme changed to dark", timestamp: "3h ago" },
];

const features = [
  { id: "discover", name: "Discover/Swipe", enabled: true },
  { id: "messaging", name: "Messaging", enabled: true },
  { id: "stories", name: "Stories", enabled: true },
  { id: "friends", name: "Friends", enabled: true },
  { id: "rooms", name: "Live Rooms", enabled: true },
  { id: "games", name: "Games", enabled: true },
  { id: "gifts", name: "Gifts", enabled: true },
  { id: "boost", name: "Profile Boost", enabled: true },
];

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [users, setUsers] = useState(mockUsers);
  const [gifts, setGifts] = useState(mockGifts);
  const [featureToggles, setFeatureToggles] = useState(features);
  const [searchQuery, setSearchQuery] = useState("");
  const [aiCommand, setAiCommand] = useState("");
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [aiMessages, setAiMessages] = useState<Array<{ role: string; content: string }>>([
    { role: "assistant", content: "Hello! I'm your AI Admin Assistant. I can help you with commands like:\n- Change theme to dark/light\n- Add/edit gift prices\n- Enable/disable features\n- Give bonus coins to users" }
  ]);

  useEffect(() => {
    const isAdmin = localStorage.getItem("sparkmatch-admin");
    if (!isAdmin) {
      setLocation("/admin/login");
    }
  }, [setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("sparkmatch-admin");
    setLocation("/admin/login");
    toast({ title: "Logged Out", description: "Admin session ended" });
  };

  const handleToggleFeature = (id: string) => {
    setFeatureToggles(prev => 
      prev.map(f => f.id === id ? { ...f, enabled: !f.enabled } : f)
    );
    toast({ title: "Feature Updated", description: `Feature toggled successfully` });
  };

  const handleBanUser = (userId: string) => {
    setUsers(prev => 
      prev.map(u => u.id === userId ? { ...u, status: u.status === "active" ? "suspended" : "active" } : u)
    );
    toast({ title: "User Status Updated" });
  };

  const handleAiCommand = () => {
    if (!aiCommand.trim()) return;

    const userMessage = aiCommand;
    setAiMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setAiCommand("");

    const lowerCommand = userMessage.toLowerCase();
    let response = "";

    if (lowerCommand.includes("theme") && lowerCommand.includes("dark")) {
      setTheme("dark");
      response = "Done! I've changed the theme to dark mode.";
    } else if (lowerCommand.includes("theme") && lowerCommand.includes("light")) {
      setTheme("light");
      response = "Done! I've changed the theme to light mode.";
    } else if (lowerCommand.includes("enable") && lowerCommand.includes("games")) {
      setFeatureToggles(prev => prev.map(f => f.id === "games" ? { ...f, enabled: true } : f));
      response = "Done! Games feature has been enabled.";
    } else if (lowerCommand.includes("disable") && lowerCommand.includes("games")) {
      setFeatureToggles(prev => prev.map(f => f.id === "games" ? { ...f, enabled: false } : f));
      response = "Done! Games feature has been disabled.";
    } else if (lowerCommand.includes("gift") && lowerCommand.includes("price")) {
      const match = lowerCommand.match(/(\w+)\s+(?:to|=)\s+(\d+)/);
      if (match) {
        const giftName = match[1];
        const newPrice = parseInt(match[2]);
        setGifts(prev => prev.map(g => 
          g.name.toLowerCase() === giftName ? { ...g, price: newPrice } : g
        ));
        response = `Done! Updated ${giftName} price to ${newPrice} coins.`;
      } else {
        response = "Please specify the gift and price, e.g., 'Set rose price to 15'";
      }
    } else if (lowerCommand.includes("bonus") && lowerCommand.includes("coins")) {
      const match = lowerCommand.match(/(\d+)\s+coins?\s+(?:to\s+)?(\w+)/i);
      if (match) {
        const amount = parseInt(match[1]);
        const username = match[2];
        setUsers(prev => prev.map(u => 
          u.username.toLowerCase().includes(username.toLowerCase()) 
            ? { ...u, coins: u.coins + amount } 
            : u
        ));
        response = `Done! Added ${amount} bonus coins.`;
      } else {
        response = "Please specify amount and user, e.g., 'Give 100 coins to sarah'";
      }
    } else {
      response = "I understood your request. Here are some things I can help with:\n- 'Change theme to dark/light'\n- 'Enable/disable games'\n- 'Set rose price to 20'\n- 'Give 100 coins to sarah'";
    }

    setTimeout(() => {
      setAiMessages(prev => [...prev, { role: "assistant", content: response }]);
    }, 500);
  };

  const stats = [
    { label: "Total Users", value: "1,234", change: "+12%", icon: Users },
    { label: "Revenue", value: "$12,450", change: "+8%", icon: TrendingUp },
    { label: "Active Subs", value: "456", change: "+5%", icon: CreditCard },
    { label: "Gifts Sent", value: "2,890", change: "+15%", icon: Gift },
  ];

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="hidden lg:flex w-64 flex-col border-r border-border p-4">
        <div className="flex items-center gap-2 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-pink-400 flex items-center justify-center">
            <span className="text-white font-bold">SM</span>
          </div>
          <div>
            <h1 className="font-bold">SparkMatch</h1>
            <p className="text-xs text-muted-foreground">Admin Panel</p>
          </div>
        </div>

        <nav className="space-y-1 flex-1">
          {[
            { id: "overview", label: "Overview", icon: TrendingUp },
            { id: "users", label: "Users", icon: Users },
            { id: "subscriptions", label: "Subscriptions", icon: CreditCard },
            { id: "gifts", label: "Gifts & Coins", icon: Gift },
            { id: "games", label: "Games", icon: Gamepad2 },
            { id: "rooms", label: "Live Rooms", icon: Radio },
            { id: "settings", label: "Settings", icon: Settings },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeTab === item.id ? "secondary" : "ghost"}
                className="w-full justify-start gap-2"
                onClick={() => setActiveTab(item.id)}
                data-testid={`nav-${item.id}`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </Button>
            );
          })}
        </nav>

        <Button variant="ghost" className="justify-start gap-2 text-destructive" onClick={handleLogout}>
          <LogOut className="w-4 h-4" />
          Logout
        </Button>
      </aside>

      <main className="flex-1 overflow-auto">
        <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-lg border-b border-border p-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold capitalize">{activeTab}</h2>
              <p className="text-sm text-muted-foreground">Manage your SparkMatch platform</p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              >
                {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </Button>
              <Dialog open={aiChatOpen} onOpenChange={setAiChatOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2" data-testid="button-ai-assistant">
                    <Bot className="w-4 h-4" /> AI Assistant
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Bot className="w-5 h-5" /> AI Admin Assistant
                    </DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="h-80 pr-4">
                    <div className="space-y-4">
                      {aiMessages.map((msg, i) => (
                        <div 
                          key={i} 
                          className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div className={`max-w-[80%] p-3 rounded-lg text-sm whitespace-pre-line ${
                            msg.role === "user" 
                              ? "bg-primary text-primary-foreground" 
                              : "bg-muted"
                          }`}>
                            {msg.content}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  <div className="flex gap-2 pt-4">
                    <Input
                      placeholder="Type a command..."
                      value={aiCommand}
                      onChange={(e) => setAiCommand(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleAiCommand()}
                      data-testid="input-ai-command"
                    />
                    <Button size="icon" onClick={handleAiCommand} data-testid="button-send-ai">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </header>

        <div className="p-6">
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {stats.map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <Card key={stat.label}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">{stat.label}</p>
                            <p className="text-2xl font-bold">{stat.value}</p>
                          </div>
                          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                            <Icon className="w-6 h-6 text-primary" />
                          </div>
                        </div>
                        <Badge variant="secondary" className="mt-2">{stat.change}</Badge>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockAuditLogs.map((log) => (
                      <div key={log.id} className="flex items-start gap-4 pb-4 border-b border-border last:border-0">
                        <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                        <div className="flex-1">
                          <p className="font-medium text-sm">{log.action}</p>
                          <p className="text-sm text-muted-foreground">{log.details}</p>
                        </div>
                        <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "users" && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button className="gap-2">
                  <Plus className="w-4 h-4" /> Add User
                </Button>
              </div>

              <Card>
                <CardContent className="p-0">
                  <div className="divide-y divide-border">
                    {users.filter(u => 
                      u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      u.displayName.toLowerCase().includes(searchQuery.toLowerCase())
                    ).map((user) => (
                      <div key={user.id} className="flex items-center gap-4 p-4" data-testid={`user-row-${user.id}`}>
                        <Avatar>
                          <AvatarFallback>{user.displayName[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium">{user.displayName}</p>
                          <p className="text-sm text-muted-foreground">@{user.username} - {user.email}</p>
                        </div>
                        <Badge variant={user.plan === "gold" ? "default" : user.plan === "silver" ? "secondary" : "outline"}>
                          {user.plan}
                        </Badge>
                        <div className="flex items-center gap-1 text-yellow-500">
                          <Coins className="w-4 h-4" />
                          <span className="font-medium">{user.coins}</span>
                        </div>
                        <Badge variant={user.status === "active" ? "secondary" : "destructive"}>
                          {user.status}
                        </Badge>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleBanUser(user.id)}
                          >
                            {user.status === "active" ? <Ban className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "gifts" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Gift Management</h3>
                <Button className="gap-2">
                  <Plus className="w-4 h-4" /> Add Gift
                </Button>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {gifts.map((gift) => (
                  <Card key={gift.id} data-testid={`admin-gift-${gift.id}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
                          <Gift className="w-6 h-6 text-primary" />
                        </div>
                        <Switch checked={gift.active} />
                      </div>
                      <p className="font-medium">{gift.name}</p>
                      <div className="flex items-center gap-1 text-yellow-500 mt-1">
                        <Coins className="w-4 h-4" />
                        <span className="font-semibold">{gift.price} coins</span>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Edit className="w-3 h-3 mr-1" /> Edit
                        </Button>
                        <Button variant="outline" size="sm">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === "settings" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="w-5 h-5" /> Theme Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Dark Mode</p>
                      <p className="text-sm text-muted-foreground">Toggle between light and dark theme</p>
                    </div>
                    <Switch 
                      checked={theme === "dark"} 
                      onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Feature Toggles</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {featureToggles.map((feature) => (
                    <div key={feature.id} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{feature.name}</p>
                      </div>
                      <Switch 
                        checked={feature.enabled}
                        onCheckedChange={() => handleToggleFeature(feature.id)}
                        data-testid={`toggle-${feature.id}`}
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Audit Logs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockAuditLogs.map((log) => (
                      <div key={log.id} className="flex items-start gap-4 pb-4 border-b border-border last:border-0">
                        <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                        <div className="flex-1">
                          <p className="font-medium text-sm">{log.action}</p>
                          <p className="text-sm text-muted-foreground">{log.details}</p>
                        </div>
                        <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {(activeTab === "subscriptions" || activeTab === "games" || activeTab === "rooms") && (
            <div className="text-center py-12">
              <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
                {activeTab === "subscriptions" && <CreditCard className="w-8 h-8 text-muted-foreground" />}
                {activeTab === "games" && <Gamepad2 className="w-8 h-8 text-muted-foreground" />}
                {activeTab === "rooms" && <Radio className="w-8 h-8 text-muted-foreground" />}
              </div>
              <h3 className="font-semibold mb-1 capitalize">{activeTab} Management</h3>
              <p className="text-sm text-muted-foreground">
                This section is ready for implementation
              </p>
            </div>
          )}
        </div>
      </main>

      <Button
        size="icon"
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg lg:hidden"
        onClick={() => setAiChatOpen(true)}
        data-testid="button-ai-fab"
      >
        <Bot className="w-6 h-6" />
      </Button>
    </div>
  );
}
