import { useState } from "react";
import { Link, useLocation } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { 
  Edit3, 
  Camera, 
  MapPin, 
  Settings, 
  LogOut,
  Crown,
  Coins,
  Zap,
  Heart,
  Users,
  Gift,
  Sparkles,
  ChevronRight
} from "lucide-react";

export default function ProfilePage() {
  const { user, updateUser, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [editOpen, setEditOpen] = useState(false);
  const [formData, setFormData] = useState({
    displayName: user?.displayName || "",
    bio: user?.bio || "",
    location: user?.location || "",
    photoUrl: user?.photoUrl || "",
    interests: user?.interests?.join(", ") || "",
  });

  const handleSave = () => {
    updateUser({
      displayName: formData.displayName,
      bio: formData.bio,
      location: formData.location,
      photoUrl: formData.photoUrl,
      interests: formData.interests.split(",").map(i => i.trim()).filter(Boolean),
    });
    toast({ title: "Profile Updated", description: "Your changes have been saved" });
    setEditOpen(false);
  };

  const handleLogout = () => {
    logout();
    setLocation("/login");
    toast({ title: "Logged Out", description: "See you next time!" });
  };

  const handleBoost = () => {
    const userCoins = user?.coins || 0;
    if (userCoins < 50) {
      toast({ title: "Not enough coins", description: "Boost costs 50 coins", variant: "destructive" });
      return;
    }
    updateUser({ coins: userCoins - 50, isBoosted: true });
    toast({ title: "Profile Boosted!", description: "You'll get more visibility for 30 minutes" });
  };

  const stats = [
    { label: "Matches", value: 24, icon: Heart },
    { label: "Friends", value: 12, icon: Users },
    { label: "Gifts", value: 8, icon: Gift },
  ];

  const menuItems = [
    { label: "Subscription", href: "/subscription", icon: Crown },
    { label: "Coins & Gifts", href: "/gifts", icon: Coins },
    { label: "Settings", href: "/settings", icon: Settings },
  ];

  return (
    <AppLayout title="Profile" showCoins={false}>
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-6">
        <section className="text-center space-y-4">
          <div className="relative inline-block">
            <Avatar className="w-28 h-28 ring-4 ring-primary ring-offset-4 ring-offset-background">
              <AvatarImage src={user?.photoUrl || undefined} />
              <AvatarFallback className="text-3xl bg-gradient-to-br from-primary to-pink-400 text-white">
                {user?.displayName?.[0] || "?"}
              </AvatarFallback>
            </Avatar>
            <Dialog open={editOpen} onOpenChange={setEditOpen}>
              <DialogTrigger asChild>
                <Button 
                  size="icon" 
                  className="absolute bottom-0 right-0 rounded-full w-10 h-10"
                  data-testid="button-edit-photo"
                >
                  <Camera className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Edit Profile</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>Photo URL</Label>
                    <Input
                      placeholder="https://example.com/photo.jpg"
                      value={formData.photoUrl}
                      onChange={(e) => setFormData({ ...formData, photoUrl: e.target.value })}
                      data-testid="input-photo-url"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Display Name</Label>
                    <Input
                      value={formData.displayName}
                      onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                      data-testid="input-display-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Bio</Label>
                    <Textarea
                      placeholder="Tell us about yourself..."
                      value={formData.bio}
                      onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                      className="resize-none"
                      data-testid="input-bio"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input
                      placeholder="City, Country"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      data-testid="input-location"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Interests (comma separated)</Label>
                    <Input
                      placeholder="Travel, Music, Cooking"
                      value={formData.interests}
                      onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
                      data-testid="input-interests"
                    />
                  </div>
                  <Button onClick={handleSave} className="w-full" data-testid="button-save-profile">
                    Save Changes
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div>
            <div className="flex items-center justify-center gap-2">
              <h1 className="text-2xl font-bold">{user?.displayName || "New User"}</h1>
              {user?.isVerified && (
                <Sparkles className="w-5 h-5 text-primary" />
              )}
            </div>
            <p className="text-muted-foreground">@{user?.username}</p>
            {user?.location && (
              <p className="text-sm text-muted-foreground flex items-center justify-center gap-1 mt-1">
                <MapPin className="w-3 h-3" /> {user.location}
              </p>
            )}
          </div>

          {user?.bio && (
            <p className="text-sm max-w-sm mx-auto">{user.bio}</p>
          )}

          {user?.interests && user.interests.length > 0 && (
            <div className="flex flex-wrap justify-center gap-2">
              {user.interests.map((interest, i) => (
                <Badge key={i} variant="secondary">{interest}</Badge>
              ))}
            </div>
          )}

          <div className="flex items-center justify-center gap-2">
            <Badge className="bg-gradient-to-r from-yellow-500 to-amber-600 gap-1">
              <Crown className="w-3 h-3" />
              {user?.subscriptionPlan === "gold" ? "Gold" : 
               user?.subscriptionPlan === "silver" ? "Silver" : "Free"} Member
            </Badge>
            {user?.isBoosted && (
              <Badge className="bg-gradient-to-r from-purple-500 to-violet-600 gap-1 animate-pulse">
                <Zap className="w-3 h-3" /> Boosted
              </Badge>
            )}
          </div>
        </section>

        <div className="grid grid-cols-3 gap-3">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.label}>
                <CardContent className="flex flex-col items-center justify-center p-4 gap-1">
                  <Icon className="w-5 h-5 text-primary" />
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Card className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-primary/20">
          <CardContent className="flex items-center justify-between gap-4 p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Zap className="w-6 h-6 text-purple-500" />
              </div>
              <div>
                <p className="font-semibold">Boost Your Profile</p>
                <p className="text-sm text-muted-foreground">Get 10x more visibility</p>
              </div>
            </div>
            <Button 
              onClick={handleBoost}
              disabled={user?.isBoosted}
              data-testid="button-boost"
            >
              <Coins className="w-4 h-4 mr-2" /> 50 coins
            </Button>
          </CardContent>
        </Card>

        <section className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.label} href={item.href}>
                <Card className="hover-elevate cursor-pointer" data-testid={`menu-${item.label.toLowerCase()}`}>
                  <CardContent className="flex items-center gap-4 p-4">
                    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="flex-1 font-medium">{item.label}</span>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </section>

        <Button 
          variant="outline" 
          className="w-full text-destructive"
          onClick={handleLogout}
          data-testid="button-logout"
        >
          <LogOut className="w-4 h-4 mr-2" /> Log Out
        </Button>
      </div>
    </AppLayout>
  );
}
