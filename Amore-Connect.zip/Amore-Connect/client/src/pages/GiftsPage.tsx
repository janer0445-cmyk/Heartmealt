import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Gift, 
  Coins,
  Heart,
  Star,
  Sparkles,
  Crown,
  Flower2,
  Gem,
  Wine,
  Coffee,
  Cake,
  Send,
  Loader2
} from "lucide-react";
import type { Gift as GiftType, User } from "@shared/schema";

const iconMap: Record<string, typeof Heart> = {
  flower2: Flower2,
  heart: Heart,
  star: Star,
  sparkles: Sparkles,
  coffee: Coffee,
  wine: Wine,
  cake: Cake,
  gem: Gem,
  crown: Crown,
};

const colorMap: Record<string, string> = {
  flower2: "text-red-500",
  heart: "text-pink-500",
  star: "text-yellow-500",
  sparkles: "text-purple-500",
  coffee: "text-amber-700",
  wine: "text-red-700",
  cake: "text-pink-400",
  gem: "text-cyan-400",
  crown: "text-yellow-500",
};

export default function GiftsPage() {
  const [selectedGift, setSelectedGift] = useState<GiftType | null>(null);
  const [selectedRecipient, setSelectedRecipient] = useState<User | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const { user, updateUser } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();

  const { data: gifts = [], isLoading: giftsLoading } = useQuery<GiftType[]>({
    queryKey: ["/api/gifts"],
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const recipients = users.filter(u => u.id !== user?.id).slice(0, 6);

  const sendGiftMutation = useMutation({
    mutationFn: async () => {
      if (!selectedGift || !selectedRecipient) throw new Error("Missing data");
      const response = await apiRequest("POST", "/api/gifts/send", {
        senderId: user?.id,
        receiverId: selectedRecipient.id,
        giftId: selectedGift.id,
      });
      return response.json();
    },
    onSuccess: () => {
      if (selectedGift && user) {
        updateUser({ coins: (user.coins || 0) - selectedGift.price });
      }
      toast({ 
        title: "Gift Sent!", 
        description: `You sent a ${selectedGift?.name} to ${selectedRecipient?.displayName}` 
      });
      queryClient.invalidateQueries({ queryKey: ["/api/gifts"] });
      setConfirmOpen(false);
      setSelectedGift(null);
      setSelectedRecipient(null);
    },
    onError: (error: Error) => {
      toast({ 
        title: "Failed to send gift", 
        description: error.message || "Please try again", 
        variant: "destructive" 
      });
    },
  });

  const handleSelectGift = (gift: GiftType) => {
    setSelectedGift(gift);
  };

  const handleSelectRecipient = (recipient: User) => {
    setSelectedRecipient(recipient);
    if (selectedGift) {
      setConfirmOpen(true);
    }
  };

  const handleSendGift = () => {
    if (!selectedGift || !selectedRecipient) return;
    
    const userCoins = user?.coins || 0;
    if (userCoins < selectedGift.price) {
      toast({ title: "Not enough coins", description: "Please purchase more coins", variant: "destructive" });
      return;
    }

    sendGiftMutation.mutate();
  };

  if (giftsLoading) {
    return (
      <AppLayout title="Gifts">
        <div className="flex items-center justify-center h-full py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Gifts">
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-6">
        <Card className="bg-gradient-to-r from-primary/10 to-pink-500/10 border-primary/20">
          <CardContent className="flex items-center justify-between gap-4 p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                <Coins className="w-6 h-6 text-yellow-500" />
              </div>
              <div>
                <p className="font-semibold">Your Balance</p>
                <p className="text-2xl font-bold text-yellow-500">{user?.coins || 0} coins</p>
              </div>
            </div>
            <Button data-testid="button-buy-coins">Buy Coins</Button>
          </CardContent>
        </Card>

        <section className="space-y-3">
          <h2 className="font-semibold flex items-center gap-2">
            <Gift className="w-4 h-4" /> Choose a Gift
          </h2>
          <div className="grid grid-cols-3 gap-3">
            {gifts.map((gift) => {
              const Icon = iconMap[gift.icon] || Gift;
              const color = colorMap[gift.icon] || "text-muted-foreground";
              const isSelected = selectedGift?.id === gift.id;
              
              return (
                <Card 
                  key={gift.id}
                  className={`cursor-pointer transition-all ${
                    isSelected ? "ring-2 ring-primary" : "hover-elevate"
                  }`}
                  onClick={() => handleSelectGift(gift)}
                  data-testid={`gift-${gift.id}`}
                >
                  <CardContent className="flex flex-col items-center justify-center p-4 gap-2">
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
                      <Icon className={`w-6 h-6 ${color}`} />
                    </div>
                    <p className="text-sm font-medium">{gift.name}</p>
                    <div className="flex items-center gap-1 text-xs text-yellow-500">
                      <Coins className="w-3 h-3" />
                      <span className="font-semibold">{gift.price}</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {selectedGift && (
          <section className="space-y-3">
            <h2 className="font-semibold">Send to</h2>
            <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
              {recipients.length > 0 ? recipients.map((recipient) => (
                <button 
                  key={recipient.id}
                  className="flex flex-col items-center gap-2 min-w-[80px]"
                  onClick={() => handleSelectRecipient(recipient)}
                  data-testid={`recipient-${recipient.id}`}
                >
                  <Avatar className={`w-16 h-16 ${
                    selectedRecipient?.id === recipient.id ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""
                  }`}>
                    <AvatarImage src={recipient.photoUrl || undefined} />
                    <AvatarFallback>{recipient.displayName?.[0]}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm">{recipient.displayName}</span>
                </button>
              )) : (
                <p className="text-muted-foreground text-sm">No recipients available. Match with someone first!</p>
              )}
            </div>
          </section>
        )}

        <section className="space-y-3">
          <h2 className="font-semibold">Recent Gifts Received</h2>
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              <Gift className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>No gifts received yet</p>
            </CardContent>
          </Card>
        </section>
      </div>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send Gift</DialogTitle>
          </DialogHeader>
          {selectedGift && selectedRecipient && (
            <div className="space-y-6 pt-4">
              <div className="flex items-center justify-center gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-xl bg-muted flex items-center justify-center mx-auto mb-2">
                    {(() => {
                      const Icon = iconMap[selectedGift.icon] || Gift;
                      const color = colorMap[selectedGift.icon] || "text-muted-foreground";
                      return <Icon className={`w-8 h-8 ${color}`} />;
                    })()}
                  </div>
                  <p className="font-medium">{selectedGift.name}</p>
                </div>
                <Send className="w-6 h-6 text-muted-foreground" />
                <div className="text-center">
                  <Avatar className="w-16 h-16 mx-auto mb-2">
                    <AvatarImage src={selectedRecipient.photoUrl || undefined} />
                    <AvatarFallback>{selectedRecipient.displayName?.[0]}</AvatarFallback>
                  </Avatar>
                  <p className="font-medium">{selectedRecipient.displayName}</p>
                </div>
              </div>

              <div className="text-center p-4 rounded-lg bg-muted">
                <p className="text-muted-foreground text-sm">Cost</p>
                <p className="text-2xl font-bold flex items-center justify-center gap-2">
                  <Coins className="w-6 h-6 text-yellow-500" />
                  {selectedGift.price} coins
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Balance after: {(user?.coins || 0) - selectedGift.price} coins
                </p>
              </div>

              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => setConfirmOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  className="flex-1"
                  onClick={handleSendGift}
                  disabled={(user?.coins || 0) < selectedGift.price || sendGiftMutation.isPending}
                  data-testid="button-confirm-send"
                >
                  {sendGiftMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Gift className="w-4 h-4 mr-2" />
                  )}
                  Send Gift
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
