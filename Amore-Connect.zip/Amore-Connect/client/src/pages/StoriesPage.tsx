import { useState } from "react";
import { Link } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Eye, Heart, MessageCircle, X, ChevronLeft, ChevronRight } from "lucide-react";

const stories = [
  {
    id: "1",
    userId: "1",
    userName: "Sarah",
    userPhoto: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    imageUrl: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800",
    caption: "Beautiful sunset hike today!",
    views: 124,
    likes: 45,
    timestamp: "2h ago",
  },
  {
    id: "2",
    userId: "2",
    userName: "Mike",
    userPhoto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    imageUrl: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800",
    caption: "Cooked this amazing dinner tonight!",
    views: 89,
    likes: 32,
    timestamp: "4h ago",
  },
  {
    id: "3",
    userId: "3",
    userName: "Emma",
    userPhoto: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
    imageUrl: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=800",
    caption: "New art piece I've been working on!",
    views: 156,
    likes: 78,
    timestamp: "6h ago",
  },
  {
    id: "4",
    userId: "4",
    userName: "Jake",
    userPhoto: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800",
    caption: "New song coming soon!",
    views: 203,
    likes: 91,
    timestamp: "8h ago",
  },
];

export default function StoriesPage() {
  const [viewingStory, setViewingStory] = useState<typeof stories[0] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [createOpen, setCreateOpen] = useState(false);
  const [newStory, setNewStory] = useState({ imageUrl: "", caption: "" });
  const { toast } = useToast();

  const openStory = (story: typeof stories[0]) => {
    setViewingStory(story);
    setCurrentIndex(stories.findIndex(s => s.id === story.id));
  };

  const nextStory = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setViewingStory(stories[currentIndex + 1]);
    } else {
      setViewingStory(null);
    }
  };

  const prevStory = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setViewingStory(stories[currentIndex - 1]);
    }
  };

  const handleCreateStory = () => {
    if (!newStory.imageUrl) {
      toast({ title: "Error", description: "Please enter an image URL", variant: "destructive" });
      return;
    }
    toast({ title: "Story Posted!", description: "Your story is now live for 24 hours" });
    setCreateOpen(false);
    setNewStory({ imageUrl: "", caption: "" });
  };

  return (
    <AppLayout title="Stories">
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-6">
        <div className="flex items-center gap-4 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <button className="flex flex-col items-center gap-1 min-w-[80px]" data-testid="button-create-story">
                <div className="w-16 h-16 rounded-full bg-muted border-2 border-dashed border-muted-foreground/50 flex items-center justify-center">
                  <Plus className="w-6 h-6 text-muted-foreground" />
                </div>
                <span className="text-xs">Add Story</span>
              </button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Story</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Image URL</label>
                  <Input
                    placeholder="https://example.com/image.jpg"
                    value={newStory.imageUrl}
                    onChange={(e) => setNewStory({ ...newStory, imageUrl: e.target.value })}
                    data-testid="input-story-image"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Caption (optional)</label>
                  <Textarea
                    placeholder="What's on your mind?"
                    value={newStory.caption}
                    onChange={(e) => setNewStory({ ...newStory, caption: e.target.value })}
                    className="resize-none"
                    data-testid="input-story-caption"
                  />
                </div>
                {newStory.imageUrl && (
                  <div className="aspect-[9/16] max-h-64 rounded-lg overflow-hidden bg-muted">
                    <img
                      src={newStory.imageUrl}
                      alt="Preview"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = "none";
                      }}
                    />
                  </div>
                )}
                <Button onClick={handleCreateStory} className="w-full" data-testid="button-post-story">
                  Post Story
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {stories.map((story) => (
            <button 
              key={story.id}
              onClick={() => openStory(story)}
              className="flex flex-col items-center gap-1 min-w-[80px]"
              data-testid={`story-preview-${story.id}`}
            >
              <div className="p-0.5 rounded-full bg-gradient-to-br from-primary via-pink-500 to-orange-400">
                <div className="p-0.5 rounded-full bg-background">
                  <Avatar className="w-14 h-14">
                    <AvatarImage src={story.userPhoto} />
                    <AvatarFallback>{story.userName[0]}</AvatarFallback>
                  </Avatar>
                </div>
              </div>
              <span className="text-xs truncate w-16 text-center">{story.userName}</span>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          {stories.map((story) => (
            <Card 
              key={story.id} 
              className="overflow-hidden cursor-pointer hover-elevate"
              onClick={() => openStory(story)}
              data-testid={`story-card-${story.id}`}
            >
              <div className="relative aspect-[9/16]">
                <img
                  src={story.imageUrl}
                  alt={story.caption}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <Avatar className="w-8 h-8 border-2 border-white">
                    <AvatarImage src={story.userPhoto} />
                    <AvatarFallback>{story.userName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="text-white">
                    <p className="text-xs font-semibold">{story.userName}</p>
                    <p className="text-[10px] opacity-80">{story.timestamp}</p>
                  </div>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <p className="text-sm line-clamp-2">{story.caption}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" /> {story.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" /> {story.likes}
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {viewingStory && (
        <div className="fixed inset-0 z-50 bg-black" data-testid="story-viewer">
          <div className="absolute top-0 left-0 right-0 z-10 p-4">
            <div className="flex gap-1 mb-4">
              {stories.map((_, index) => (
                <div 
                  key={index}
                  className={`h-0.5 flex-1 rounded-full ${
                    index <= currentIndex ? "bg-white" : "bg-white/30"
                  }`}
                />
              ))}
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10 border-2 border-white">
                  <AvatarImage src={viewingStory.userPhoto} />
                  <AvatarFallback>{viewingStory.userName[0]}</AvatarFallback>
                </Avatar>
                <div className="text-white">
                  <p className="font-semibold">{viewingStory.userName}</p>
                  <p className="text-xs opacity-80">{viewingStory.timestamp}</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white"
                onClick={() => setViewingStory(null)}
                data-testid="button-close-story"
              >
                <X className="w-6 h-6" />
              </Button>
            </div>
          </div>

          <img
            src={viewingStory.imageUrl}
            alt={viewingStory.caption}
            className="w-full h-full object-contain"
          />

          <button
            className="absolute left-0 top-0 bottom-0 w-[40%]"
            onClick={prevStory}
            aria-label="Previous story"
          />
          <button
            className="absolute right-0 top-0 bottom-0 w-[60%]"
            onClick={nextStory}
            aria-label="Next story"
          />

          <div className="absolute bottom-0 left-0 right-0 z-10 p-4 bg-gradient-to-t from-black/80 to-transparent">
            {viewingStory.caption && (
              <p className="text-white mb-4">{viewingStory.caption}</p>
            )}
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" className="text-white gap-2">
                <Heart className="w-5 h-5" /> {viewingStory.likes}
              </Button>
              <Button variant="ghost" size="sm" className="text-white gap-2">
                <MessageCircle className="w-5 h-5" /> Reply
              </Button>
            </div>
          </div>

          {currentIndex > 0 && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-2 top-1/2 -translate-y-1/2 text-white"
              onClick={prevStory}
            >
              <ChevronLeft className="w-8 h-8" />
            </Button>
          )}
          {currentIndex < stories.length - 1 && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 -translate-y-1/2 text-white"
              onClick={nextStory}
            >
              <ChevronRight className="w-8 h-8" />
            </Button>
          )}
        </div>
      )}
    </AppLayout>
  );
}
