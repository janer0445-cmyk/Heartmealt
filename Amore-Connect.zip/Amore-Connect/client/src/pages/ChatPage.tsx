import { useState, useRef, useEffect } from "react";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import { 
  ArrowLeft, 
  MoreVertical, 
  Send, 
  Gift, 
  Image,
  Phone,
  Video
} from "lucide-react";

const chatData: Record<string, { name: string; photoUrl: string; online: boolean }> = {
  "1": { name: "Sarah", photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150", online: true },
  "2": { name: "Mike", photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150", online: false },
  "3": { name: "Emma", photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150", online: true },
  "4": { name: "Jake", photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150", online: false },
  "5": { name: "Lisa", photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150", online: true },
};

const initialMessages = [
  { id: "1", senderId: "other", content: "Hey! I saw we matched, how are you?", timestamp: "10:30 AM" },
  { id: "2", senderId: "me", content: "Hi! I'm great, thanks for reaching out!", timestamp: "10:32 AM" },
  { id: "3", senderId: "other", content: "I noticed you like hiking too! Do you have any favorite trails?", timestamp: "10:33 AM" },
  { id: "4", senderId: "me", content: "Yes! I love the trails in the national park nearby. Have you been?", timestamp: "10:35 AM" },
  { id: "5", senderId: "other", content: "Not yet, but I've been wanting to check it out. Maybe we could go together sometime?", timestamp: "10:36 AM" },
];

export default function ChatPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [messages, setMessages] = useState(initialMessages);
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatUser = chatData[id || "1"] || chatData["1"];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!newMessage.trim()) return;
    
    setMessages([
      ...messages,
      {
        id: Date.now().toString(),
        senderId: "me",
        content: newMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
    setNewMessage("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-3">
            <Link href="/messages">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={chatUser.photoUrl} />
                  <AvatarFallback>{chatUser.name[0]}</AvatarFallback>
                </Avatar>
                {chatUser.online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-status-online rounded-full border-2 border-background" />
                )}
              </div>
              <div>
                <h2 className="font-semibold text-sm">{chatUser.name}</h2>
                <p className="text-xs text-muted-foreground">
                  {chatUser.online ? "Online" : "Offline"}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" data-testid="button-call">
              <Phone className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" data-testid="button-video">
              <Video className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" data-testid="button-more">
              <MoreVertical className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => {
          const isMe = message.senderId === "me";
          const showTimestamp = index === 0 || 
            messages[index - 1].timestamp !== message.timestamp;

          return (
            <div key={message.id}>
              {showTimestamp && (
                <div className="text-center mb-2">
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                    {message.timestamp}
                  </span>
                </div>
              )}
              <div className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                {!isMe && (
                  <Avatar className="w-8 h-8 mr-2 shrink-0">
                    <AvatarImage src={chatUser.photoUrl} />
                    <AvatarFallback>{chatUser.name[0]}</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
                    isMe
                      ? "bg-primary text-primary-foreground rounded-br-md"
                      : "bg-muted rounded-bl-md"
                  }`}
                  data-testid={`message-${message.id}`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      <div className="sticky bottom-0 bg-background border-t border-border p-4">
        <div className="flex items-center gap-2 max-w-2xl mx-auto">
          <Button variant="ghost" size="icon" data-testid="button-attach">
            <Image className="w-5 h-5" />
          </Button>
          <Link href={`/gifts?to=${id}`}>
            <Button variant="ghost" size="icon" data-testid="button-gift">
              <Gift className="w-5 h-5" />
            </Button>
          </Link>
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 rounded-full"
            data-testid="input-message"
          />
          <Button 
            size="icon" 
            className="rounded-full shrink-0"
            onClick={handleSend}
            disabled={!newMessage.trim()}
            data-testid="button-send"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
