import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Check, Crown, Sparkles, Star, Loader2 } from "lucide-react";

const plans = [
  {
    id: "free",
    name: "Free",
    price: 0,
    coins: 10,
    icon: Star,
    color: "from-slate-500 to-slate-600",
    features: [
      "5 swipes per day",
      "Basic profile",
      "View matches",
      "Limited messaging",
      "10 free coins",
    ],
    popular: false,
  },
  {
    id: "silver",
    name: "Silver",
    price: 9.99,
    coins: 100,
    icon: Sparkles,
    color: "from-slate-400 to-slate-500",
    features: [
      "Unlimited swipes",
      "See who likes you",
      "Unlimited messaging",
      "Priority matching",
      "100 bonus coins",
      "1 free boost/month",
    ],
    popular: false,
  },
  {
    id: "gold",
    name: "Gold",
    price: 19.99,
    coins: 500,
    icon: Crown,
    color: "from-yellow-500 to-amber-600",
    features: [
      "Everything in Silver",
      "Top picks daily",
      "Super likes (5/day)",
      "Profile boost (3/month)",
      "500 bonus coins",
      "Exclusive badges",
      "Priority support",
    ],
    popular: true,
  },
];

export default function SubscriptionPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { selectSubscription, user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSelectPlan = async (planId: string) => {
    setSelectedPlan(planId);
    setIsLoading(true);
    
    const success = await selectSubscription(planId);
    setIsLoading(false);
    
    if (success) {
      const plan = plans.find(p => p.id === planId);
      toast({ 
        title: "Subscription Activated!", 
        description: `You're now on the ${plan?.name} plan with ${plan?.coins} coins!` 
      });
      setLocation("/");
    } else {
      toast({ 
        title: "Error", 
        description: "Failed to activate subscription", 
        variant: "destructive" 
      });
    }
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">Choose Your Plan</h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Select a subscription to unlock premium features and start connecting
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const isCurrentPlan = user?.subscriptionPlan === plan.id;
            
            return (
              <Card 
                key={plan.id}
                className={`relative overflow-visible transition-all duration-300 ${
                  plan.popular ? "ring-2 ring-primary scale-105 md:scale-110" : ""
                } ${selectedPlan === plan.id ? "ring-2 ring-primary" : ""}`}
                data-testid={`card-plan-${plan.id}`}
              >
                {plan.popular && (
                  <Badge 
                    className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary"
                  >
                    Most Popular
                  </Badge>
                )}
                
                <CardHeader className="text-center pb-2">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${plan.color} mx-auto flex items-center justify-center mb-2`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>
                    <span className="text-3xl font-bold text-foreground">
                      ${plan.price}
                    </span>
                    {plan.price > 0 && <span className="text-muted-foreground">/month</span>}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground">
                    <span className="font-semibold text-yellow-500">{plan.coins}</span>
                    <span>bonus coins included</span>
                  </div>

                  <Button
                    className="w-full"
                    variant={plan.popular ? "default" : "outline"}
                    disabled={isLoading || isCurrentPlan}
                    onClick={() => handleSelectPlan(plan.id)}
                    data-testid={`button-select-${plan.id}`}
                  >
                    {isLoading && selectedPlan === plan.id ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : isCurrentPlan ? (
                      "Current Plan"
                    ) : plan.price === 0 ? (
                      "Start Free"
                    ) : (
                      "Subscribe"
                    )}
                  </Button>

                  {plan.price > 0 && (
                    <p className="text-xs text-center text-muted-foreground">
                      Payment simulated - Flutterwave ready
                    </p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <p className="text-center text-sm text-muted-foreground">
          All plans include a 7-day money-back guarantee
        </p>
      </div>
    </div>
  );
}
