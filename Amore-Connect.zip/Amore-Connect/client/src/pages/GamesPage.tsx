import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Gamepad2, 
  Users, 
  Coins, 
  Trophy, 
  Play,
  X,
  Loader2
} from "lucide-react";
import type { Game } from "@shared/schema";

const gameColors: Record<string, string> = {
  "truth-or-dare": "from-pink-500 to-rose-500",
  "would-you-rather": "from-purple-500 to-violet-500",
  "trivia-night": "from-blue-500 to-cyan-500",
  "never-have-i": "from-orange-500 to-amber-500",
  "emoji-guess": "from-green-500 to-emerald-500",
  "kiss-marry-avoid": "from-red-500 to-pink-500",
};

const leaderboard = [
  { rank: 1, name: "Sarah", coins: 2450, photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150" },
  { rank: 2, name: "Mike", coins: 2100, photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150" },
  { rank: 3, name: "Emma", coins: 1890, photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150" },
];

export default function GamesPage() {
  const { user, updateUser } = useAuth();
  const [activeGame, setActiveGame] = useState<Game | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: games = [], isLoading } = useQuery<Game[]>({
    queryKey: ["/api/games"],
  });

  const createSessionMutation = useMutation({
    mutationFn: async (gameId: string) => {
      const response = await apiRequest("POST", "/api/games/session", {
        gameId,
        players: [user?.id],
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSessionId(data.id);
      setIsSearching(false);
      setIsPlaying(true);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to start game", variant: "destructive" });
      setIsSearching(false);
    },
  });

  const endGameMutation = useMutation({
    mutationFn: async (winnerId: string) => {
      if (!sessionId) throw new Error("No session");
      const response = await apiRequest("POST", `/api/games/session/${sessionId}/end`, {
        winnerId,
      });
      return response.json();
    },
    onSuccess: () => {
      if (activeGame && user) {
        const reward = activeGame.coinReward || 0;
        updateUser({ coins: (user.coins || 0) + reward });
        toast({ title: "Game Over!", description: `You earned ${reward} coins!` });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setActiveGame(null);
      setIsPlaying(false);
      setSessionId(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to end game", variant: "destructive" });
    },
  });

  const handlePlay = (game: Game) => {
    setActiveGame(game);
    setIsSearching(true);
    createSessionMutation.mutate(game.id);
  };

  const handleEndGame = () => {
    if (user?.id) {
      endGameMutation.mutate(user.id);
    }
  };

  if (isLoading) {
    return (
      <AppLayout title="Games">
        <div className="flex items-center justify-center h-full py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Games">
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-6">
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold flex items-center gap-2">
              <Trophy className="w-4 h-4 text-yellow-500" /> Leaderboard
            </h2>
            <Badge variant="secondary">This Week</Badge>
          </div>
          <Card>
            <CardContent className="p-4 space-y-3">
              {leaderboard.map((player) => (
                <div key={player.rank} className="flex items-center gap-3" data-testid={`leaderboard-${player.rank}`}>
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    player.rank === 1 ? "bg-yellow-500 text-black" :
                    player.rank === 2 ? "bg-gray-300 text-black" :
                    "bg-amber-600 text-white"
                  }`}>
                    {player.rank}
                  </span>
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={player.photoUrl} />
                    <AvatarFallback>{player.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{player.name}</p>
                  </div>
                  <div className="flex items-center gap-1 text-yellow-500">
                    <Coins className="w-4 h-4" />
                    <span className="font-semibold text-sm">{player.coins}</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </section>

        <section className="space-y-3">
          <h2 className="font-semibold flex items-center gap-2">
            <Gamepad2 className="w-4 h-4" /> Play Games
          </h2>
          <div className="grid gap-4">
            {games.map((game) => {
              const colorClass = gameColors[game.id] || "from-gray-500 to-slate-500";
              return (
                <Card key={game.id} className="overflow-hidden" data-testid={`game-${game.id}`}>
                  <div className={`h-24 bg-gradient-to-r ${colorClass} flex items-center justify-center`}>
                    <Gamepad2 className="w-12 h-12 text-white/80" />
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="font-semibold">{game.name}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">{game.description}</p>
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" /> {game.minPlayers}-{game.maxPlayers} players
                          </span>
                          <span className="flex items-center gap-1 text-yellow-500">
                            <Coins className="w-3 h-3" /> +{game.coinReward} coins
                          </span>
                        </div>
                      </div>
                      <Button 
                        className="shrink-0 gap-2"
                        onClick={() => handlePlay(game)}
                        disabled={createSessionMutation.isPending}
                        data-testid={`button-play-${game.id}`}
                      >
                        <Play className="w-4 h-4" /> Play
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      </div>

      <Dialog open={!!activeGame} onOpenChange={() => { setActiveGame(null); setIsPlaying(false); setIsSearching(false); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{activeGame?.name}</DialogTitle>
          </DialogHeader>
          
          {isSearching && (
            <div className="py-12 text-center space-y-4">
              <Loader2 className="w-12 h-12 animate-spin mx-auto text-primary" />
              <p className="text-muted-foreground">Finding players...</p>
            </div>
          )}

          {isPlaying && activeGame && (
            <div className="space-y-6">
              <div className="text-center py-8">
                <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${gameColors[activeGame.id] || "from-gray-500 to-slate-500"} mx-auto flex items-center justify-center mb-4`}>
                  <Gamepad2 className="w-10 h-10 text-white" />
                </div>
                <p className="text-lg font-semibold mb-2">Game in Progress!</p>
                <p className="text-muted-foreground text-sm">
                  This is a demo. In the full version, you'd be playing {activeGame.name} with other users!
                </p>
              </div>

              <div className="flex items-center justify-center gap-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary">+{activeGame.coinReward}</p>
                  <p className="text-sm text-muted-foreground">Coins on win</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => { setActiveGame(null); setIsPlaying(false); }}
                  data-testid="button-quit-game"
                >
                  <X className="w-4 h-4 mr-2" /> Quit
                </Button>
                <Button 
                  className="flex-1"
                  onClick={handleEndGame}
                  disabled={endGameMutation.isPending}
                  data-testid="button-win-game"
                >
                  {endGameMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Trophy className="w-4 h-4 mr-2" />
                  )}
                  Win (Demo)
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
