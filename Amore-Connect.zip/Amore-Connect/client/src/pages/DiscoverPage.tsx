import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Heart, 
  X, 
  Star, 
  MapPin, 
  Grid3X3, 
  Layers,
  Sparkles,
  RefreshCw,
  Loader2
} from "lucide-react";
import type { User } from "@shared/schema";

const fallbackProfiles = [
  {
    id: "demo-1",
    username: "sarah_j",
    displayName: "Sarah",
    age: 26,
    location: "New York, NY",
    bio: "Coffee addict & adventure seeker. Looking for someone to explore the city with.",
    photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800",
    interests: ["Travel", "Photography", "Coffee", "Hiking"],
    isVerified: true,
    isOnline: true,
  },
  {
    id: "demo-2",
    username: "mike_t",
    displayName: "Mike",
    age: 29,
    location: "Los Angeles, CA",
    bio: "Tech enthusiast by day, chef by night. Let's cook something up!",
    photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800",
    interests: ["Cooking", "Technology", "Music", "Fitness"],
    isVerified: true,
    isOnline: false,
  },
  {
    id: "demo-3",
    username: "emma_w",
    displayName: "Emma",
    age: 24,
    location: "Chicago, IL",
    bio: "Artist with a passion for life. Every day is a new canvas.",
    photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=800",
    interests: ["Art", "Music", "Books", "Wine"],
    isVerified: false,
    isOnline: true,
  },
  {
    id: "demo-4",
    username: "jake_r",
    displayName: "Jake",
    age: 28,
    location: "Austin, TX",
    bio: "Musician, dog dad, and eternal optimist. Let's make memories!",
    photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800",
    interests: ["Music", "Dogs", "Travel", "Sports"],
    isVerified: true,
    isOnline: true,
  },
];

export default function DiscoverPage() {
  const { user } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [view, setView] = useState<"swipe" | "grid">("swipe");
  const { toast } = useToast();

  const { data: apiUsers = [], isLoading, refetch } = useQuery<User[]>({
    queryKey: ["/api/users"],
    staleTime: 30000,
  });

  const profiles = apiUsers.length > 0 
    ? apiUsers.filter(u => u.id !== user?.id).map(u => ({
        id: u.id,
        username: u.username,
        displayName: u.displayName,
        age: u.age,
        location: u.location || "Unknown",
        bio: u.bio || "",
        photoUrl: u.photoUrl || "",
        interests: u.interests || [],
        isVerified: u.isVerified || false,
        isOnline: u.isOnline || false,
      }))
    : fallbackProfiles;

  const swipeMutation = useMutation({
    mutationFn: async ({ targetId, liked }: { targetId: string; liked: boolean }) => {
      const response = await apiRequest("POST", "/api/matches/swipe", {
        userId: user?.id,
        targetId,
        liked,
      });
      return response.json();
    },
    onSuccess: (data, variables) => {
      if (data.isMatch) {
        toast({ 
          title: "It's a Match!", 
          description: "You both liked each other! Start chatting now." 
        });
      } else if (variables.liked) {
        toast({ title: "Liked!", description: `You liked ${profiles[currentIndex]?.displayName}` });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/matches"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to record swipe", variant: "destructive" });
    },
  });

  const currentProfile = profiles[currentIndex];

  const handleSwipe = (direction: "left" | "right" | "super") => {
    if (!currentProfile) return;

    const liked = direction !== "left";
    swipeMutation.mutate({ targetId: currentProfile.id, liked });

    if (direction === "super") {
      toast({ title: "Super Like!", description: `You super liked ${currentProfile.displayName}` });
    }
    
    if (currentIndex < profiles.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
      toast({ title: "That's everyone!", description: "Come back later for more matches" });
    }
  };

  const handleGridLike = (profile: typeof profiles[0]) => {
    swipeMutation.mutate({ targetId: profile.id, liked: true });
    toast({ title: "Liked!", description: `You liked ${profile.displayName}` });
  };

  if (isLoading) {
    return (
      <AppLayout title="Discover">
        <div className="flex items-center justify-center h-full py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Discover">
      <div className="max-w-2xl mx-auto px-4 py-4">
        <Tabs value={view} onValueChange={(v) => setView(v as "swipe" | "grid")}>
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger value="swipe" className="gap-2" data-testid="tab-swipe">
                <Layers className="w-4 h-4" /> Swipe
              </TabsTrigger>
              <TabsTrigger value="grid" className="gap-2" data-testid="tab-grid">
                <Grid3X3 className="w-4 h-4" /> Grid
              </TabsTrigger>
            </TabsList>
            <Button 
              variant="ghost" 
              size="icon" 
              data-testid="button-refresh"
              onClick={() => refetch()}
            >
              <RefreshCw className="w-5 h-5" />
            </Button>
          </div>

          <TabsContent value="swipe" className="mt-0">
            {currentProfile ? (
              <>
                <div className="relative aspect-[3/4] max-h-[70vh] rounded-3xl overflow-hidden">
                  <Avatar className="w-full h-full rounded-none">
                    <AvatarImage 
                      src={currentProfile.photoUrl} 
                      alt={currentProfile.displayName}
                      className="w-full h-full object-cover"
                    />
                    <AvatarFallback className="w-full h-full rounded-none text-6xl">
                      {currentProfile.displayName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  <div className="absolute top-4 right-4 flex gap-2">
                    {currentProfile.isVerified && (
                      <Badge className="bg-blue-500/90 backdrop-blur-sm">
                        <Sparkles className="w-3 h-3 mr-1" /> Verified
                      </Badge>
                    )}
                    {currentProfile.isOnline && (
                      <Badge className="bg-green-500/90 backdrop-blur-sm">Online</Badge>
                    )}
                  </div>

                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <div className="space-y-2">
                      <h2 className="text-3xl font-bold">
                        {currentProfile.displayName}, {currentProfile.age}
                      </h2>
                      <div className="flex items-center gap-1 text-white/80">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">{currentProfile.location}</span>
                      </div>
                      <p className="text-sm text-white/90 line-clamp-2">
                        {currentProfile.bio}
                      </p>
                      <div className="flex flex-wrap gap-2 pt-2">
                        {(currentProfile.interests || []).slice(0, 4).map((interest) => (
                          <Badge 
                            key={interest} 
                            variant="secondary" 
                            className="bg-white/20 text-white border-0 backdrop-blur-sm"
                          >
                            {interest}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-4 mt-6">
                  <Button
                    size="icon"
                    variant="outline"
                    className="w-16 h-16 rounded-full border-2 border-destructive text-destructive"
                    onClick={() => handleSwipe("left")}
                    disabled={swipeMutation.isPending}
                    data-testid="button-dislike"
                  >
                    <X className="w-7 h-7" />
                  </Button>
                  <Button
                    size="icon"
                    className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500"
                    onClick={() => handleSwipe("super")}
                    disabled={swipeMutation.isPending}
                    data-testid="button-superlike"
                  >
                    <Star className="w-6 h-6 text-white" fill="white" />
                  </Button>
                  <Button
                    size="icon"
                    className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-pink-500"
                    onClick={() => handleSwipe("right")}
                    disabled={swipeMutation.isPending}
                    data-testid="button-like"
                  >
                    <Heart className="w-7 h-7 text-white" fill="white" />
                  </Button>
                </div>
              </>
            ) : (
              <div className="text-center py-20">
                <div className="w-20 h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
                  <Heart className="w-10 h-10 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">No more profiles</h3>
                <p className="text-muted-foreground mb-4">Check back later for more matches!</p>
                <Button onClick={() => setCurrentIndex(0)}>Start Over</Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="grid" className="mt-0">
            <div className="grid grid-cols-2 gap-3">
              {profiles.map((profile) => (
                <Card 
                  key={profile.id}
                  className="overflow-hidden hover-elevate cursor-pointer"
                  data-testid={`card-profile-${profile.id}`}
                >
                  <div className="relative aspect-[3/4]">
                    <Avatar className="w-full h-full rounded-none">
                      <AvatarImage 
                        src={profile.photoUrl} 
                        alt={profile.displayName}
                        className="w-full h-full object-cover"
                      />
                      <AvatarFallback className="w-full h-full rounded-none text-4xl">
                        {profile.displayName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    
                    {profile.isVerified && (
                      <Badge className="absolute top-2 right-2 bg-blue-500/90">
                        <Sparkles className="w-3 h-3" />
                      </Badge>
                    )}

                    <div className="absolute bottom-0 left-0 right-0 p-3 text-white">
                      <p className="font-semibold">
                        {profile.displayName}, {profile.age}
                      </p>
                      <p className="text-xs text-white/80 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {profile.location?.split(",")[0]}
                      </p>
                    </div>
                  </div>
                  <CardContent className="p-2">
                    <Button 
                      size="sm" 
                      className="w-full gap-2"
                      onClick={() => handleGridLike(profile)}
                      disabled={swipeMutation.isPending}
                      data-testid={`button-like-${profile.id}`}
                    >
                      <Heart className="w-4 h-4" /> Like
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
