import { useState } from "react";
import { Link } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Heart, 
  MessageCircle, 
  Users, 
  Gamepad2, 
  Gift, 
  Radio, 
  BookOpen,
  Sparkles,
  TrendingUp,
  Zap
} from "lucide-react";

const quickActions = [
  { icon: Heart, label: "Discover", href: "/discover", color: "from-pink-500 to-rose-500" },
  { icon: MessageCircle, label: "Messages", href: "/messages", color: "from-blue-500 to-cyan-500" },
  { icon: Users, label: "Friends", href: "/friends", color: "from-green-500 to-emerald-500" },
  { icon: Radio, label: "Live Rooms", href: "/rooms", color: "from-purple-500 to-violet-500" },
  { icon: Gamepad2, label: "Games", href: "/games", color: "from-orange-500 to-amber-500" },
  { icon: Gift, label: "Gifts", href: "/gifts", color: "from-red-500 to-pink-500" },
];

const recentMatches = [
  { id: "1", name: "Sarah", photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150", online: true },
  { id: "2", name: "Mike", photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150", online: false },
  { id: "3", name: "Emma", photoUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150", online: true },
  { id: "4", name: "Jake", photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150", online: false },
];

const trendingStories = [
  { id: "1", name: "You", photoUrl: null, hasStory: false, isOwn: true },
  { id: "2", name: "Lisa", photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150", hasStory: true },
  { id: "3", name: "Tom", photoUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150", hasStory: true },
  { id: "4", name: "Amy", photoUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150", hasStory: true },
  { id: "5", name: "Chris", photoUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150", hasStory: true },
];

export default function HomePage() {
  const { user } = useAuth();
  const [activeTab] = useState("home");

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-6">
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Hello, {user?.displayName || "Friend"}</h2>
              <p className="text-muted-foreground">Ready to find your spark?</p>
            </div>
            <Link href="/profile">
              <Avatar className="w-12 h-12 ring-2 ring-primary ring-offset-2 ring-offset-background cursor-pointer">
                <AvatarImage src={user?.photoUrl || undefined} />
                <AvatarFallback className="bg-gradient-to-br from-primary to-pink-400 text-white">
                  {user?.displayName?.[0] || "?"}
                </AvatarFallback>
              </Avatar>
            </Link>
          </div>

          {user?.subscriptionPlan === "free" && (
            <Card className="bg-gradient-to-r from-primary/10 to-pink-500/10 border-primary/20">
              <CardContent className="flex items-center justify-between gap-4 p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Upgrade to Premium</p>
                    <p className="text-xs text-muted-foreground">Unlock unlimited features</p>
                  </div>
                </div>
                <Link href="/subscription">
                  <Button size="sm" data-testid="button-upgrade">
                    Upgrade
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> Stories
            </h3>
            <Link href="/stories" className="text-primary text-sm">See all</Link>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
            {trendingStories.map((story) => (
              <Link key={story.id} href={story.isOwn ? "/stories/create" : `/stories/${story.id}`}>
                <div className="flex flex-col items-center gap-1 min-w-[64px]" data-testid={`story-${story.id}`}>
                  <div className={`p-0.5 rounded-full ${story.hasStory ? "bg-gradient-to-br from-primary via-pink-500 to-orange-400" : story.isOwn ? "bg-muted" : "bg-border"}`}>
                    <div className="p-0.5 rounded-full bg-background">
                      <Avatar className="w-14 h-14">
                        {story.isOwn ? (
                          <div className="w-full h-full bg-muted flex items-center justify-center">
                            <span className="text-2xl text-muted-foreground">+</span>
                          </div>
                        ) : (
                          <>
                            <AvatarImage src={story.photoUrl || undefined} />
                            <AvatarFallback>{story.name[0]}</AvatarFallback>
                          </>
                        )}
                      </Avatar>
                    </div>
                  </div>
                  <span className="text-xs truncate w-16 text-center">
                    {story.isOwn ? "Add Story" : story.name}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Zap className="w-4 h-4" /> Quick Actions
          </h3>
          <div className="grid grid-cols-3 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Link key={action.label} href={action.href}>
                  <Card className="hover-elevate cursor-pointer transition-all">
                    <CardContent className="flex flex-col items-center justify-center p-4 gap-2">
                      <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${action.color} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <span className="text-xs font-medium">{action.label}</span>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4" /> Recent Matches
            </h3>
            <Link href="/messages" className="text-primary text-sm">View all</Link>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
            {recentMatches.map((match) => (
              <Link key={match.id} href={`/chat/${match.id}`}>
                <Card className="min-w-[100px] hover-elevate cursor-pointer" data-testid={`match-${match.id}`}>
                  <CardContent className="flex flex-col items-center p-3 gap-2">
                    <div className="relative">
                      <Avatar className="w-14 h-14">
                        <AvatarImage src={match.photoUrl} />
                        <AvatarFallback>{match.name[0]}</AvatarFallback>
                      </Avatar>
                      {match.online && (
                        <div className="absolute bottom-0 right-0 w-4 h-4 bg-status-online rounded-full border-2 border-background" />
                      )}
                    </div>
                    <span className="text-sm font-medium">{match.name}</span>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Radio className="w-4 h-4" /> Live Now
          </h3>
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div className="relative h-32 bg-gradient-to-br from-purple-600 to-pink-500">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white">
                    <Badge variant="destructive" className="mb-2 animate-pulse">
                      LIVE
                    </Badge>
                    <p className="font-semibold">Speed Dating Night</p>
                    <p className="text-sm opacity-90">45 people joined</p>
                  </div>
                </div>
              </div>
              <div className="p-4 flex items-center justify-between">
                <div className="flex -space-x-2">
                  {recentMatches.slice(0, 3).map((m) => (
                    <Avatar key={m.id} className="w-8 h-8 border-2 border-background">
                      <AvatarImage src={m.photoUrl} />
                      <AvatarFallback>{m.name[0]}</AvatarFallback>
                    </Avatar>
                  ))}
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-medium border-2 border-background">
                    +42
                  </div>
                </div>
                <Link href="/rooms">
                  <Button size="sm" data-testid="button-join-room">
                    Join Room
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </AppLayout>
  );
}
