import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  photoUrl: text("photo_url"),
  bio: text("bio"),
  age: integer("age").notNull(),
  gender: text("gender").notNull(),
  location: text("location"),
  interests: text("interests").array(),
  subscriptionPlan: text("subscription_plan").default("free"),
  coins: integer("coins").default(0),
  isBoosted: boolean("is_boosted").default(false),
  boostExpiresAt: timestamp("boost_expires_at"),
  isOnline: boolean("is_online").default(false),
  isAdmin: boolean("is_admin").default(false),
  isVerified: boolean("is_verified").default(false),
  ageConfirmed: boolean("age_confirmed").default(false),
});

export const subscriptionPlans = pgTable("subscription_plans", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  price: integer("price").notNull(),
  coins: integer("coins").notNull(),
  features: text("features").array(),
  isActive: boolean("is_active").default(true),
});

export const matches = pgTable("matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId1: varchar("user_id_1").notNull(),
  userId2: varchar("user_id_2").notNull(),
  isMatched: boolean("is_matched").default(false),
  user1Liked: boolean("user1_liked").default(false),
  user2Liked: boolean("user2_liked").default(false),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull(),
  receiverId: varchar("receiver_id").notNull(),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const stories = pgTable("stories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  imageUrl: text("image_url").notNull(),
  caption: text("caption"),
  expiresAt: timestamp("expires_at").notNull(),
  views: integer("views").default(0),
});

export const friends = pgTable("friends", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  friendId: varchar("friend_id").notNull(),
  status: text("status").default("pending"),
});

export const rooms = pgTable("rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  topic: text("topic"),
  hostId: varchar("host_id").notNull(),
  participants: text("participants").array(),
  isLive: boolean("is_live").default(true),
  maxParticipants: integer("max_participants").default(50),
});

export const roomMessages = pgTable("room_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull(),
  userId: varchar("user_id").notNull(),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const games = pgTable("games", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  minPlayers: integer("min_players").default(2),
  maxPlayers: integer("max_players").default(4),
  coinReward: integer("coin_reward").default(10),
  isActive: boolean("is_active").default(true),
});

export const gameSessions = pgTable("game_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").notNull(),
  players: text("players").array(),
  winnerId: varchar("winner_id"),
  status: text("status").default("waiting"),
});

export const gifts = pgTable("gifts", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  price: integer("price").notNull(),
  isActive: boolean("is_active").default(true),
});

export const giftTransactions = pgTable("gift_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull(),
  receiverId: varchar("receiver_id").notNull(),
  giftId: varchar("gift_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  adminId: varchar("admin_id").notNull(),
  action: text("action").notNull(),
  details: text("details"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const appConfig = pgTable("app_config", {
  id: varchar("id").primaryKey().default("main"),
  theme: text("theme").default("default"),
  primaryColor: text("primary_color").default("#ec4899"),
  featuresEnabled: text("features_enabled").array(),
  boostPrice: integer("boost_price").default(50),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertSubscriptionSchema = createInsertSchema(subscriptionPlans);
export const insertMatchSchema = createInsertSchema(matches).omit({ id: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, timestamp: true });
export const insertStorySchema = createInsertSchema(stories).omit({ id: true });
export const insertFriendSchema = createInsertSchema(friends).omit({ id: true });
export const insertRoomSchema = createInsertSchema(rooms).omit({ id: true });
export const insertRoomMessageSchema = createInsertSchema(roomMessages).omit({ id: true, timestamp: true });
export const insertGameSchema = createInsertSchema(games);
export const insertGameSessionSchema = createInsertSchema(gameSessions).omit({ id: true });
export const insertGiftSchema = createInsertSchema(gifts);
export const insertGiftTransactionSchema = createInsertSchema(giftTransactions).omit({ id: true, timestamp: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, timestamp: true });
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, timestamp: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type Match = typeof matches.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Story = typeof stories.$inferSelect;
export type Friend = typeof friends.$inferSelect;
export type Room = typeof rooms.$inferSelect;
export type RoomMessage = typeof roomMessages.$inferSelect;
export type Game = typeof games.$inferSelect;
export type GameSession = typeof gameSessions.$inferSelect;
export type Gift = typeof gifts.$inferSelect;
export type GiftTransaction = typeof giftTransactions.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
export type AppConfig = typeof appConfig.$inferSelect;

export const loginSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(6),
});

export const signupSchema = z.object({
  username: z.string().min(3),
  email: z.string().email(),
  password: z.string().min(6),
  displayName: z.string().min(2),
  age: z.number().min(18),
  gender: z.string(),
  ageConfirmed: z.boolean().refine(val => val === true, "You must confirm you are 18+"),
});

export type LoginInput = z.infer<typeof loginSchema>;
export type SignupInput = z.infer<typeof signupSchema>;
