# Design Guidelines: Social Dating PWA

## Design Approach
**Reference-Based:** Drawing from modern dating apps (Tinder, Bumble, Hinge) combined with social features (Instagram stories) and community elements (Discord live rooms). Focus on visual appeal, emotional engagement, and seamless mobile-first interactions.

## Core Design Principles
1. **Mobile-First Intimacy:** Optimize for thumb-friendly interactions and single-handed use
2. **Visual Hierarchy:** Profile photos and user content are hero elements
3. **Playful Professionalism:** Fun and engaging while maintaining trust and safety
4. **Instant Gratification:** Fast, satisfying feedback on all interactions

## Typography System
**Primary Font:** Inter or DM Sans (Google Fonts CDN)
**Secondary Font:** Outfit or Space Grotesk for headings

**Hierarchy:**
- Page titles: 2xl to 3xl, bold weight
- Section headers: xl to 2xl, semibold
- Body text: base to lg, regular weight
- Captions/metadata: sm to xs, medium weight
- Button text: base, semibold weight

## Layout & Spacing System
**Tailwind Spacing Units:** Consistently use 2, 4, 6, 8, 12, 16, 20, 24 units
- Component padding: p-4 to p-6
- Section spacing: py-8 to py-16
- Card gaps: gap-4 to gap-6
- Icon spacing: p-2 to p-3

**Container Strategy:**
- Max width: max-w-7xl for desktop, max-w-md for mobile app views
- Edge padding: px-4 on mobile, px-8 on desktop
- Full-bleed sections for profile cards and stories

## Component Library

### Navigation
**Bottom Tab Bar (Mobile):**
- Fixed bottom navigation with 5 icons: Home, Discover, Messages, Stories, Profile
- Active state with icon fill and subtle indicator
- Icon size: w-6 h-6 with p-3 touch target

**Top Bar:**
- Logo/app name left-aligned
- Notification bell and settings icon right-aligned
- Coin balance display (icon + number) in header for easy access
- Subtle drop shadow for depth

### Profile Cards (Discovery)
**Swipe View:**
- Full-screen card deck with rounded-3xl corners
- Large profile image (70% of card height)
- Gradient overlay at bottom for text readability
- Name, age, location in 2xl bold on gradient
- Bio snippet in base weight (2-3 lines max)
- Swipe action buttons: Large circular buttons (w-16 h-16) at bottom - X (left), Star/Super Like (center), Heart (right)
- Buttons with blurred backdrop and subtle shadow

**List View:**
- Grid layout: grid-cols-2 on mobile, grid-cols-3 to 4 on desktop
- Card aspect ratio: 3:4 portrait
- Rounded-2xl cards with image, name overlay at bottom
- Hover lift effect on desktop

### Chat Interface
**Inbox List:**
- Avatar (w-14 h-14) with rounded-full
- Unread indicator: Small badge on avatar
- Name in semibold, last message preview in regular
- Timestamp aligned right in sm text
- Divider between conversations

**Message View:**
- Sticky header with match avatar, name, and menu dots
- Messages: max-w-xs to max-w-sm bubbles with rounded-2xl
- Sender messages aligned right, receiver left
- Timestamp below message groups (not every message)
- Input bar: Fixed bottom with rounded-full text field, attachment icon, send button
- Generous padding (p-3 to p-4) in input area

### Stories Feature
**Story Ring:**
- Circular avatars (w-16 h-16) with gradient ring for unviewed, simple border for viewed
- Horizontal scroll row at top of feed
- "Your Story" card with + icon first in row

**Story Viewer:**
- Full-screen overlay with progress bars at top
- Tap zones: left 40% for previous, right 60% for next
- Close button (X) top-right, user info top-left
- Reaction bar at bottom: Quick emoji reactions or text reply

### Live Rooms
**Room Cards:**
- Rounded-2xl cards with participant count, topic, and host info
- Live indicator: Pulsing red dot + "LIVE" badge
- Grid of first 4 participant avatars in 2x2 overlapping layout
- Join button with blurred background

**Active Room:**
- Participant list at top in scrollable row
- Speaking indicator: Subtle glow around active speaker avatar
- Chat area with auto-scroll
- Leave/mute controls in sticky bottom bar

### Games Section
**Game Cards:**
- Landscape cards (16:9 ratio) with game artwork/preview
- Rounded-2xl with slight shadow
- Game title overlay at bottom with gradient backdrop
- Player count and coin reward badge top-right
- Grid: Single column mobile, 2-3 columns desktop

### Subscription Plans
**Plan Cards:**
- Vertical cards with clear tier hierarchy
- Featured plan (Gold): Larger scale (scale-105) with glow effect
- Plan name in 2xl bold at top
- Feature list with checkmark icons
- Price in 3xl bold, billing period in sm
- CTA button spanning full width at bottom
- Cards in row on desktop, stack on mobile

### Gifts Marketplace
**Gift Grid:**
- Grid: grid-cols-3 to 4 on mobile, grid-cols-4 to 6 on desktop
- Square aspect ratio with rounded-xl
- Gift icon/image centered
- Coin cost at bottom in semibold
- Send button appears on selection

### Admin Dashboard
**Sidebar Navigation:**
- Fixed left sidebar (w-64) with hierarchical menu
- Icon + label for each section
- Collapsible on mobile to hamburger menu
- Active state with background fill

**Data Tables:**
- Striped rows for readability
- Action buttons (edit, delete) right-aligned
- Search and filter bar above table
- Pagination below table

**AI Assistant Panel:**
- Fixed bottom-right chat bubble (w-12 h-12)
- Expands to chat interface (max-w-md)
- Message bubbles similar to user chat but distinct styling
- Quick action chips for common commands

## Micro-interactions
- Card lift on hover (desktop): translate-y-1
- Button press: scale-95 on active
- Loading states: Skeleton screens with shimmer effect
- Success feedback: Checkmark animation or confetti for gifts/matches
- Pull-to-refresh on mobile feeds

## Image Strategy
**Hero Sections:** No traditional hero - app opens directly to discovery feed (card swipes)

**Required Images:**
- User profile photos (URL-based, user-provided)
- Story content (URL-based)
- Gift icons/illustrations (use emoji or simple SVG icons from Heroicons)
- Game preview artwork (placeholder gradients with game titles)
- Default avatars for new users (geometric patterns or initials)

**Image Treatment:**
- All user photos: object-cover with rounded corners
- Aspect ratios: Profile cards 3:4, thumbnails 1:1, stories 9:16
- Lazy loading for feed images

## Accessibility
- Min touch target: 44x44px (Tailwind's p-3 achieves this)
- Form labels visible and associated
- ARIA labels for icon-only buttons
- Focus indicators on all interactive elements
- Alt text for all images

## PWA-Specific Elements
**Install Prompt:**
- Sticky banner at top or bottom on first visit
- Dismissible but returns after 3 sessions
- Clear "Add to Home Screen" CTA

**Offline State:**
- Friendly offline message when no connection
- Cached profile and recent messages accessible
- Clear "Reconnecting..." indicator

This design creates a visually rich, engaging dating experience that balances playfulness with professionalism, optimized for mobile-first interactions while scaling beautifully to desktop.