import { 
  type User, 
  type InsertUser,
  type SubscriptionPlan,
  type Match,
  type Message,
  type Story,
  type Friend,
  type Room,
  type RoomMessage,
  type Game,
  type GameSession,
  type Gift,
  type GiftTransaction,
  type Notification,
  type AuditLog,
  type AppConfig
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  deleteUser(id: string): Promise<boolean>;

  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  getSubscriptionPlan(id: string): Promise<SubscriptionPlan | undefined>;

  createMatch(userId1: string, userId2: string, liked: boolean): Promise<Match>;
  getMatchesForUser(userId: string): Promise<Match[]>;
  getMatch(userId1: string, userId2: string): Promise<Match | undefined>;
  updateMatch(id: string, updates: Partial<Match>): Promise<Match | undefined>;

  createMessage(senderId: string, receiverId: string, content: string): Promise<Message>;
  getConversation(userId1: string, userId2: string): Promise<Message[]>;
  getConversationsForUser(userId: string): Promise<{ partnerId: string; messages: Message[] }[]>;
  markMessageRead(id: string): Promise<void>;

  createStory(userId: string, imageUrl: string, caption: string | null): Promise<Story>;
  getStories(): Promise<Story[]>;
  getStoriesForUser(userId: string): Promise<Story[]>;
  deleteStory(id: string): Promise<boolean>;

  createFriendRequest(userId: string, friendId: string): Promise<Friend>;
  getFriendsForUser(userId: string): Promise<Friend[]>;
  updateFriendStatus(id: string, status: string): Promise<Friend | undefined>;

  createRoom(name: string, topic: string | null, hostId: string): Promise<Room>;
  getRooms(): Promise<Room[]>;
  getRoom(id: string): Promise<Room | undefined>;
  updateRoom(id: string, updates: Partial<Room>): Promise<Room | undefined>;
  deleteRoom(id: string): Promise<boolean>;

  createRoomMessage(roomId: string, userId: string, content: string): Promise<RoomMessage>;
  getRoomMessages(roomId: string): Promise<RoomMessage[]>;

  getGames(): Promise<Game[]>;
  getGame(id: string): Promise<Game | undefined>;
  updateGame(id: string, updates: Partial<Game>): Promise<Game | undefined>;

  createGameSession(gameId: string, players: string[]): Promise<GameSession>;
  getGameSession(id: string): Promise<GameSession | undefined>;
  updateGameSession(id: string, updates: Partial<GameSession>): Promise<GameSession | undefined>;

  getGifts(): Promise<Gift[]>;
  getGift(id: string): Promise<Gift | undefined>;
  updateGift(id: string, updates: Partial<Gift>): Promise<Gift | undefined>;
  createGift(gift: Gift): Promise<Gift>;

  createGiftTransaction(senderId: string, receiverId: string, giftId: string): Promise<GiftTransaction>;
  getGiftTransactionsForUser(userId: string): Promise<GiftTransaction[]>;

  createNotification(userId: string, type: string, title: string, message: string): Promise<Notification>;
  getNotificationsForUser(userId: string): Promise<Notification[]>;
  markNotificationRead(id: string): Promise<void>;

  createAuditLog(adminId: string, action: string, details: string | null): Promise<AuditLog>;
  getAuditLogs(): Promise<AuditLog[]>;

  getConfig(): Promise<AppConfig>;
  updateConfig(updates: Partial<AppConfig>): Promise<AppConfig>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private subscriptionPlans: Map<string, SubscriptionPlan>;
  private matches: Map<string, Match>;
  private messages: Map<string, Message>;
  private stories: Map<string, Story>;
  private friends: Map<string, Friend>;
  private rooms: Map<string, Room>;
  private roomMessages: Map<string, RoomMessage>;
  private games: Map<string, Game>;
  private gameSessions: Map<string, GameSession>;
  private gifts: Map<string, Gift>;
  private giftTransactions: Map<string, GiftTransaction>;
  private notifications: Map<string, Notification>;
  private auditLogs: Map<string, AuditLog>;
  private config: AppConfig;

  constructor() {
    this.users = new Map();
    this.subscriptionPlans = new Map();
    this.matches = new Map();
    this.messages = new Map();
    this.stories = new Map();
    this.friends = new Map();
    this.rooms = new Map();
    this.roomMessages = new Map();
    this.games = new Map();
    this.gameSessions = new Map();
    this.gifts = new Map();
    this.giftTransactions = new Map();
    this.notifications = new Map();
    this.auditLogs = new Map();
    
    this.config = {
      id: "main",
      theme: "default",
      primaryColor: "#ec4899",
      featuresEnabled: ["discover", "messaging", "stories", "friends", "rooms", "games", "gifts", "boost"],
      boostPrice: 50,
    };

    this.initializeData();
  }

  private initializeData() {
    const plans: SubscriptionPlan[] = [
      { id: "free", name: "Free", price: 0, coins: 10, features: ["5 swipes/day", "Basic profile", "View matches", "Limited messaging"], isActive: true },
      { id: "silver", name: "Silver", price: 999, coins: 100, features: ["Unlimited swipes", "See who likes you", "Unlimited messaging", "Priority matching", "1 boost/month"], isActive: true },
      { id: "gold", name: "Gold", price: 1999, coins: 500, features: ["Everything in Silver", "Top picks daily", "Super likes", "3 boosts/month", "Exclusive badges", "Priority support"], isActive: true },
    ];
    plans.forEach(p => this.subscriptionPlans.set(p.id, p));

    const defaultGifts: Gift[] = [
      { id: "rose", name: "Rose", icon: "flower2", price: 10, isActive: true },
      { id: "heart", name: "Heart", icon: "heart", price: 15, isActive: true },
      { id: "star", name: "Star", icon: "star", price: 20, isActive: true },
      { id: "sparkle", name: "Sparkle", icon: "sparkles", price: 25, isActive: true },
      { id: "coffee", name: "Coffee", icon: "coffee", price: 30, isActive: true },
      { id: "wine", name: "Wine", icon: "wine", price: 40, isActive: true },
      { id: "cake", name: "Cake", icon: "cake", price: 50, isActive: true },
      { id: "gem", name: "Diamond", icon: "gem", price: 100, isActive: true },
      { id: "crown", name: "Crown", icon: "crown", price: 200, isActive: true },
    ];
    defaultGifts.forEach(g => this.gifts.set(g.id, g));

    const defaultGames: Game[] = [
      { id: "truth-or-dare", name: "Truth or Dare", description: "The classic party game!", minPlayers: 2, maxPlayers: 8, coinReward: 25, isActive: true },
      { id: "would-you-rather", name: "Would You Rather", description: "Choose between two scenarios!", minPlayers: 2, maxPlayers: 10, coinReward: 15, isActive: true },
      { id: "trivia-night", name: "Trivia Night", description: "Test your knowledge!", minPlayers: 2, maxPlayers: 6, coinReward: 50, isActive: true },
      { id: "never-have-i", name: "Never Have I Ever", description: "Discover fun facts!", minPlayers: 2, maxPlayers: 8, coinReward: 20, isActive: true },
      { id: "emoji-guess", name: "Emoji Charades", description: "Guess from emojis!", minPlayers: 2, maxPlayers: 4, coinReward: 30, isActive: true },
      { id: "kiss-marry-avoid", name: "Kiss, Marry, Avoid", description: "The dating game of choices!", minPlayers: 2, maxPlayers: 6, coinReward: 20, isActive: true },
    ];
    defaultGames.forEach(g => this.games.set(g.id, g));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      photoUrl: insertUser.photoUrl || null,
      bio: insertUser.bio || null,
      location: insertUser.location || null,
      interests: insertUser.interests || null,
      subscriptionPlan: "free",
      coins: 10,
      isBoosted: false,
      boostExpiresAt: null,
      isOnline: true,
      isAdmin: false,
      isVerified: false,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...updates };
    this.users.set(id, updated);
    return updated;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return Array.from(this.subscriptionPlans.values());
  }

  async getSubscriptionPlan(id: string): Promise<SubscriptionPlan | undefined> {
    return this.subscriptionPlans.get(id);
  }

  async createMatch(userId1: string, userId2: string, liked: boolean): Promise<Match> {
    const existing = await this.getMatch(userId1, userId2);
    if (existing) {
      const updates: Partial<Match> = {};
      if (existing.userId1 === userId1) {
        updates.user1Liked = liked;
      } else {
        updates.user2Liked = liked;
      }
      if ((existing.user1Liked || updates.user1Liked) && (existing.user2Liked || updates.user2Liked)) {
        updates.isMatched = true;
      }
      return (await this.updateMatch(existing.id, updates))!;
    }

    const id = randomUUID();
    const match: Match = {
      id,
      userId1,
      userId2,
      isMatched: false,
      user1Liked: liked,
      user2Liked: false,
    };
    this.matches.set(id, match);
    return match;
  }

  async getMatchesForUser(userId: string): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      m => (m.userId1 === userId || m.userId2 === userId) && m.isMatched
    );
  }

  async getMatch(userId1: string, userId2: string): Promise<Match | undefined> {
    return Array.from(this.matches.values()).find(
      m => (m.userId1 === userId1 && m.userId2 === userId2) || 
           (m.userId1 === userId2 && m.userId2 === userId1)
    );
  }

  async updateMatch(id: string, updates: Partial<Match>): Promise<Match | undefined> {
    const match = this.matches.get(id);
    if (!match) return undefined;
    const updated = { ...match, ...updates };
    this.matches.set(id, updated);
    return updated;
  }

  async createMessage(senderId: string, receiverId: string, content: string): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      id,
      senderId,
      receiverId,
      content,
      isRead: false,
      timestamp: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getConversation(userId1: string, userId2: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => 
        (m.senderId === userId1 && m.receiverId === userId2) ||
        (m.senderId === userId2 && m.receiverId === userId1)
      )
      .sort((a, b) => new Date(a.timestamp!).getTime() - new Date(b.timestamp!).getTime());
  }

  async getConversationsForUser(userId: string): Promise<{ partnerId: string; messages: Message[] }[]> {
    const userMessages = Array.from(this.messages.values()).filter(
      m => m.senderId === userId || m.receiverId === userId
    );
    
    const partners = new Set<string>();
    userMessages.forEach(m => {
      partners.add(m.senderId === userId ? m.receiverId : m.senderId);
    });

    return Array.from(partners).map(partnerId => ({
      partnerId,
      messages: userMessages
        .filter(m => m.senderId === partnerId || m.receiverId === partnerId)
        .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime()),
    }));
  }

  async markMessageRead(id: string): Promise<void> {
    const message = this.messages.get(id);
    if (message) {
      this.messages.set(id, { ...message, isRead: true });
    }
  }

  async createStory(userId: string, imageUrl: string, caption: string | null): Promise<Story> {
    const id = randomUUID();
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);
    
    const story: Story = {
      id,
      userId,
      imageUrl,
      caption,
      expiresAt,
      views: 0,
    };
    this.stories.set(id, story);
    return story;
  }

  async getStories(): Promise<Story[]> {
    const now = new Date();
    return Array.from(this.stories.values()).filter(s => new Date(s.expiresAt) > now);
  }

  async getStoriesForUser(userId: string): Promise<Story[]> {
    return Array.from(this.stories.values()).filter(s => s.userId === userId);
  }

  async deleteStory(id: string): Promise<boolean> {
    return this.stories.delete(id);
  }

  async createFriendRequest(userId: string, friendId: string): Promise<Friend> {
    const id = randomUUID();
    const friend: Friend = {
      id,
      userId,
      friendId,
      status: "pending",
    };
    this.friends.set(id, friend);
    return friend;
  }

  async getFriendsForUser(userId: string): Promise<Friend[]> {
    return Array.from(this.friends.values()).filter(
      f => f.userId === userId || f.friendId === userId
    );
  }

  async updateFriendStatus(id: string, status: string): Promise<Friend | undefined> {
    const friend = this.friends.get(id);
    if (!friend) return undefined;
    const updated = { ...friend, status };
    this.friends.set(id, updated);
    return updated;
  }

  async createRoom(name: string, topic: string | null, hostId: string): Promise<Room> {
    const id = randomUUID();
    const room: Room = {
      id,
      name,
      topic,
      hostId,
      participants: [hostId],
      isLive: true,
      maxParticipants: 50,
    };
    this.rooms.set(id, room);
    return room;
  }

  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values()).filter(r => r.isLive);
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async updateRoom(id: string, updates: Partial<Room>): Promise<Room | undefined> {
    const room = this.rooms.get(id);
    if (!room) return undefined;
    const updated = { ...room, ...updates };
    this.rooms.set(id, updated);
    return updated;
  }

  async deleteRoom(id: string): Promise<boolean> {
    return this.rooms.delete(id);
  }

  async createRoomMessage(roomId: string, userId: string, content: string): Promise<RoomMessage> {
    const id = randomUUID();
    const message: RoomMessage = {
      id,
      roomId,
      userId,
      content,
      timestamp: new Date(),
    };
    this.roomMessages.set(id, message);
    return message;
  }

  async getRoomMessages(roomId: string): Promise<RoomMessage[]> {
    return Array.from(this.roomMessages.values())
      .filter(m => m.roomId === roomId)
      .sort((a, b) => new Date(a.timestamp!).getTime() - new Date(b.timestamp!).getTime());
  }

  async getGames(): Promise<Game[]> {
    return Array.from(this.games.values()).filter(g => g.isActive);
  }

  async getGame(id: string): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async updateGame(id: string, updates: Partial<Game>): Promise<Game | undefined> {
    const game = this.games.get(id);
    if (!game) return undefined;
    const updated = { ...game, ...updates };
    this.games.set(id, updated);
    return updated;
  }

  async createGameSession(gameId: string, players: string[]): Promise<GameSession> {
    const id = randomUUID();
    const session: GameSession = {
      id,
      gameId,
      players,
      winnerId: null,
      status: "waiting",
    };
    this.gameSessions.set(id, session);
    return session;
  }

  async getGameSession(id: string): Promise<GameSession | undefined> {
    return this.gameSessions.get(id);
  }

  async updateGameSession(id: string, updates: Partial<GameSession>): Promise<GameSession | undefined> {
    const session = this.gameSessions.get(id);
    if (!session) return undefined;
    const updated = { ...session, ...updates };
    this.gameSessions.set(id, updated);
    return updated;
  }

  async getGifts(): Promise<Gift[]> {
    return Array.from(this.gifts.values()).filter(g => g.isActive);
  }

  async getGift(id: string): Promise<Gift | undefined> {
    return this.gifts.get(id);
  }

  async updateGift(id: string, updates: Partial<Gift>): Promise<Gift | undefined> {
    const gift = this.gifts.get(id);
    if (!gift) return undefined;
    const updated = { ...gift, ...updates };
    this.gifts.set(id, updated);
    return updated;
  }

  async createGift(gift: Gift): Promise<Gift> {
    this.gifts.set(gift.id, gift);
    return gift;
  }

  async createGiftTransaction(senderId: string, receiverId: string, giftId: string): Promise<GiftTransaction> {
    const id = randomUUID();
    const transaction: GiftTransaction = {
      id,
      senderId,
      receiverId,
      giftId,
      timestamp: new Date(),
    };
    this.giftTransactions.set(id, transaction);
    return transaction;
  }

  async getGiftTransactionsForUser(userId: string): Promise<GiftTransaction[]> {
    return Array.from(this.giftTransactions.values()).filter(
      t => t.senderId === userId || t.receiverId === userId
    );
  }

  async createNotification(userId: string, type: string, title: string, message: string): Promise<Notification> {
    const id = randomUUID();
    const notification: Notification = {
      id,
      userId,
      type,
      title,
      message,
      isRead: false,
      timestamp: new Date(),
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async getNotificationsForUser(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime());
  }

  async markNotificationRead(id: string): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      this.notifications.set(id, { ...notification, isRead: true });
    }
  }

  async createAuditLog(adminId: string, action: string, details: string | null): Promise<AuditLog> {
    const id = randomUUID();
    const log: AuditLog = {
      id,
      adminId,
      action,
      details,
      timestamp: new Date(),
    };
    this.auditLogs.set(id, log);
    return log;
  }

  async getAuditLogs(): Promise<AuditLog[]> {
    return Array.from(this.auditLogs.values())
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime());
  }

  async getConfig(): Promise<AppConfig> {
    return this.config;
  }

  async updateConfig(updates: Partial<AppConfig>): Promise<AppConfig> {
    this.config = { ...this.config, ...updates };
    return this.config;
  }
}

export const storage = new MemStorage();
