import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcryptjs";
import { z } from "zod";

const loginSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(6),
});

const signupSchema = z.object({
  username: z.string().min(3),
  email: z.string().email(),
  password: z.string().min(6),
  displayName: z.string().min(2),
  age: z.number().min(18),
  gender: z.string(),
  ageConfirmed: z.boolean(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const data = signupSchema.parse(req.body);
      
      if (!data.ageConfirmed) {
        return res.status(400).json({ error: "Age confirmation required" });
      }

      const existingUser = await storage.getUserByUsername(data.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already exists" });
      }

      const hashedPassword = await bcrypt.hash(data.password, 10);
      
      const user = await storage.createUser({
        username: data.username,
        email: data.email,
        password: hashedPassword,
        displayName: data.displayName,
        age: data.age,
        gender: data.gender,
        ageConfirmed: data.ageConfirmed,
      });

      const { password: _, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(data.username);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(data.password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      await storage.updateUser(user.id, { isOnline: true });
      
      const { password: _, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users", async (req, res) => {
    const users = await storage.getAllUsers();
    const safeUsers = users.map(({ password: _, ...u }) => u);
    res.json(safeUsers);
  });

  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const { password: _, ...safeUser } = user;
    res.json(safeUser);
  });

  app.patch("/api/users/:id", async (req, res) => {
    const user = await storage.updateUser(req.params.id, req.body);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const { password: _, ...safeUser } = user;
    res.json(safeUser);
  });

  app.get("/api/subscriptions", async (req, res) => {
    const plans = await storage.getSubscriptionPlans();
    res.json(plans);
  });

  app.post("/api/subscriptions/select", async (req, res) => {
    const { userId, planId } = req.body;
    
    const plan = await storage.getSubscriptionPlan(planId);
    if (!plan) {
      return res.status(404).json({ error: "Plan not found" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const updatedUser = await storage.updateUser(userId, {
      subscriptionPlan: planId,
      coins: (user.coins || 0) + plan.coins,
    });

    const { password: _, ...safeUser } = updatedUser!;
    res.json({ user: safeUser });
  });

  app.post("/api/matches/swipe", async (req, res) => {
    const { userId, targetId, liked } = req.body;
    
    const match = await storage.createMatch(userId, targetId, liked);
    
    if (match.isMatched) {
      await storage.createNotification(
        userId, 
        "match", 
        "New Match!", 
        "You have a new match!"
      );
      await storage.createNotification(
        targetId, 
        "match", 
        "New Match!", 
        "You have a new match!"
      );
    }
    
    res.json({ match, isMatch: match.isMatched });
  });

  app.get("/api/matches/:userId", async (req, res) => {
    const matches = await storage.getMatchesForUser(req.params.userId);
    res.json(matches);
  });

  app.post("/api/messages", async (req, res) => {
    const { senderId, receiverId, content } = req.body;
    const message = await storage.createMessage(senderId, receiverId, content);
    
    await storage.createNotification(
      receiverId,
      "message",
      "New Message",
      `You have a new message`
    );
    
    res.json(message);
  });

  app.get("/api/messages/:userId1/:userId2", async (req, res) => {
    const messages = await storage.getConversation(req.params.userId1, req.params.userId2);
    res.json(messages);
  });

  app.get("/api/conversations/:userId", async (req, res) => {
    const conversations = await storage.getConversationsForUser(req.params.userId);
    res.json(conversations);
  });

  app.post("/api/stories", async (req, res) => {
    const { userId, imageUrl, caption } = req.body;
    const story = await storage.createStory(userId, imageUrl, caption);
    res.json(story);
  });

  app.get("/api/stories", async (req, res) => {
    const stories = await storage.getStories();
    res.json(stories);
  });

  app.delete("/api/stories/:id", async (req, res) => {
    const deleted = await storage.deleteStory(req.params.id);
    res.json({ success: deleted });
  });

  app.post("/api/friends/request", async (req, res) => {
    const { userId, friendId } = req.body;
    const friend = await storage.createFriendRequest(userId, friendId);
    
    await storage.createNotification(
      friendId,
      "friend",
      "Friend Request",
      `You have a new friend request`
    );
    
    res.json(friend);
  });

  app.get("/api/friends/:userId", async (req, res) => {
    const friends = await storage.getFriendsForUser(req.params.userId);
    res.json(friends);
  });

  app.patch("/api/friends/:id", async (req, res) => {
    const { status } = req.body;
    const friend = await storage.updateFriendStatus(req.params.id, status);
    res.json(friend);
  });

  app.post("/api/rooms", async (req, res) => {
    const { name, topic, hostId } = req.body;
    const room = await storage.createRoom(name, topic, hostId);
    res.json(room);
  });

  app.get("/api/rooms", async (req, res) => {
    const rooms = await storage.getRooms();
    res.json(rooms);
  });

  app.get("/api/rooms/:id", async (req, res) => {
    const room = await storage.getRoom(req.params.id);
    if (!room) {
      return res.status(404).json({ error: "Room not found" });
    }
    res.json(room);
  });

  app.post("/api/rooms/:id/join", async (req, res) => {
    const { userId } = req.body;
    const room = await storage.getRoom(req.params.id);
    if (!room) {
      return res.status(404).json({ error: "Room not found" });
    }
    
    const participants = [...(room.participants || []), userId];
    const updated = await storage.updateRoom(req.params.id, { participants });
    res.json(updated);
  });

  app.post("/api/rooms/:id/leave", async (req, res) => {
    const { userId } = req.body;
    const room = await storage.getRoom(req.params.id);
    if (!room) {
      return res.status(404).json({ error: "Room not found" });
    }
    
    const participants = (room.participants || []).filter(p => p !== userId);
    const updated = await storage.updateRoom(req.params.id, { participants });
    res.json(updated);
  });

  app.post("/api/rooms/:id/messages", async (req, res) => {
    const { userId, content } = req.body;
    const message = await storage.createRoomMessage(req.params.id, userId, content);
    res.json(message);
  });

  app.get("/api/rooms/:id/messages", async (req, res) => {
    const messages = await storage.getRoomMessages(req.params.id);
    res.json(messages);
  });

  app.get("/api/games", async (req, res) => {
    const games = await storage.getGames();
    res.json(games);
  });

  app.post("/api/games/session", async (req, res) => {
    const { gameId, players } = req.body;
    const session = await storage.createGameSession(gameId, players);
    res.json(session);
  });

  app.post("/api/games/session/:id/end", async (req, res) => {
    const { winnerId } = req.body;
    const session = await storage.getGameSession(req.params.id);
    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }

    const updated = await storage.updateGameSession(req.params.id, { 
      status: "completed", 
      winnerId 
    });

    if (winnerId) {
      const game = await storage.getGame(session.gameId);
      if (game) {
        const user = await storage.getUser(winnerId);
        if (user) {
          await storage.updateUser(winnerId, { 
            coins: (user.coins || 0) + (game.coinReward || 0) 
          });
        }
      }
    }

    res.json(updated);
  });

  app.get("/api/gifts", async (req, res) => {
    const gifts = await storage.getGifts();
    res.json(gifts);
  });

  app.post("/api/gifts/send", async (req, res) => {
    const { senderId, receiverId, giftId } = req.body;
    
    const gift = await storage.getGift(giftId);
    if (!gift) {
      return res.status(404).json({ error: "Gift not found" });
    }

    const sender = await storage.getUser(senderId);
    if (!sender) {
      return res.status(404).json({ error: "Sender not found" });
    }

    if ((sender.coins || 0) < gift.price) {
      return res.status(400).json({ error: "Insufficient coins" });
    }

    await storage.updateUser(senderId, { coins: (sender.coins || 0) - gift.price });

    const receiver = await storage.getUser(receiverId);
    if (receiver) {
      const coinReward = Math.floor(gift.price * 0.5);
      await storage.updateUser(receiverId, { coins: (receiver.coins || 0) + coinReward });
    }

    const transaction = await storage.createGiftTransaction(senderId, receiverId, giftId);

    await storage.createNotification(
      receiverId,
      "gift",
      "Gift Received!",
      `You received a ${gift.name}!`
    );

    res.json(transaction);
  });

  app.post("/api/boost", async (req, res) => {
    const { userId } = req.body;
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const config = await storage.getConfig();
    const boostPrice = config.boostPrice || 50;

    if ((user.coins || 0) < boostPrice) {
      return res.status(400).json({ error: "Insufficient coins" });
    }

    const boostExpiresAt = new Date();
    boostExpiresAt.setMinutes(boostExpiresAt.getMinutes() + 30);

    const updated = await storage.updateUser(userId, {
      coins: (user.coins || 0) - boostPrice,
      isBoosted: true,
      boostExpiresAt,
    });

    const { password: _, ...safeUser } = updated!;
    res.json({ user: safeUser });
  });

  app.get("/api/notifications/:userId", async (req, res) => {
    const notifications = await storage.getNotificationsForUser(req.params.userId);
    res.json(notifications);
  });

  app.patch("/api/notifications/:id/read", async (req, res) => {
    await storage.markNotificationRead(req.params.id);
    res.json({ success: true });
  });

  app.get("/api/admin/users", async (req, res) => {
    const users = await storage.getAllUsers();
    const safeUsers = users.map(({ password: _, ...u }) => u);
    res.json(safeUsers);
  });

  app.patch("/api/admin/users/:id", async (req, res) => {
    const user = await storage.updateUser(req.params.id, req.body);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    await storage.createAuditLog(
      "admin",
      "User updated",
      `Updated user ${user.username}`
    );
    
    const { password: _, ...safeUser } = user;
    res.json(safeUser);
  });

  app.delete("/api/admin/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (user) {
      await storage.createAuditLog(
        "admin",
        "User deleted",
        `Deleted user ${user.username}`
      );
    }
    const deleted = await storage.deleteUser(req.params.id);
    res.json({ success: deleted });
  });

  app.patch("/api/admin/gifts/:id", async (req, res) => {
    const gift = await storage.updateGift(req.params.id, req.body);
    if (!gift) {
      return res.status(404).json({ error: "Gift not found" });
    }
    
    await storage.createAuditLog(
      "admin",
      "Gift updated",
      `Updated gift ${gift.name}`
    );
    
    res.json(gift);
  });

  app.patch("/api/admin/games/:id", async (req, res) => {
    const game = await storage.updateGame(req.params.id, req.body);
    if (!game) {
      return res.status(404).json({ error: "Game not found" });
    }
    
    await storage.createAuditLog(
      "admin",
      "Game updated",
      `Updated game ${game.name}`
    );
    
    res.json(game);
  });

  app.get("/api/admin/config", async (req, res) => {
    const config = await storage.getConfig();
    res.json(config);
  });

  app.patch("/api/admin/config", async (req, res) => {
    const config = await storage.updateConfig(req.body);
    
    await storage.createAuditLog(
      "admin",
      "Config updated",
      JSON.stringify(req.body)
    );
    
    res.json(config);
  });

  app.get("/api/admin/audit-logs", async (req, res) => {
    const logs = await storage.getAuditLogs();
    res.json(logs);
  });

  app.post("/api/admin/ai-command", async (req, res) => {
    const { command } = req.body;
    const lowerCommand = command.toLowerCase();
    let response = "";
    let action = "";

    if (lowerCommand.includes("theme") && lowerCommand.includes("dark")) {
      await storage.updateConfig({ theme: "dark" });
      response = "Theme changed to dark mode.";
      action = "Theme changed to dark";
    } else if (lowerCommand.includes("theme") && lowerCommand.includes("light")) {
      await storage.updateConfig({ theme: "light" });
      response = "Theme changed to light mode.";
      action = "Theme changed to light";
    } else if (lowerCommand.includes("gift") && lowerCommand.includes("price")) {
      const match = lowerCommand.match(/(\w+)\s+(?:to|=)\s+(\d+)/);
      if (match) {
        const giftName = match[1];
        const newPrice = parseInt(match[2]);
        const gifts = await storage.getGifts();
        const gift = gifts.find(g => g.name.toLowerCase() === giftName);
        if (gift) {
          await storage.updateGift(gift.id, { price: newPrice });
          response = `Updated ${gift.name} price to ${newPrice} coins.`;
          action = `Gift price updated: ${gift.name} to ${newPrice}`;
        } else {
          response = "Gift not found.";
        }
      } else {
        response = "Please specify the gift and price.";
      }
    } else if (lowerCommand.includes("bonus") && lowerCommand.includes("coins")) {
      const match = lowerCommand.match(/(\d+)\s+coins?\s+(?:to\s+)?(\w+)/i);
      if (match) {
        const amount = parseInt(match[1]);
        const username = match[2];
        const user = await storage.getUserByUsername(username);
        if (user) {
          await storage.updateUser(user.id, { coins: (user.coins || 0) + amount });
          response = `Added ${amount} bonus coins to ${user.displayName}.`;
          action = `Bonus coins: ${amount} to ${user.displayName}`;
        } else {
          response = "User not found.";
        }
      } else {
        response = "Please specify amount and user.";
      }
    } else {
      response = "Command not recognized. Try: 'change theme to dark', 'set rose price to 20', 'give 100 coins to username'";
    }

    if (action) {
      await storage.createAuditLog("admin", "AI Command", action);
    }

    res.json({ response, action });
  });

  return httpServer;
}
